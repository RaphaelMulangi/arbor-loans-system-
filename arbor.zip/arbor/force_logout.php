<?php
session_start();

// Check if logged in and user is Super Admin
if (!isset($_SESSION['admin_id']) || $_SESSION['admin_role'] !== 'Super Admin') {
    header('HTTP/1.1 403 Forbidden');
    echo "Access denied.";
    exit;
}

// Database connection (adjust your settings)
$host = 'localhost';
$db = 'your_db_name';
$user = 'your_db_user';
$pass = 'your_db_pass';

$dsn = "mysql:host=$host;dbname=$db;charset=utf8mb4";

try {
    $pdo = new PDO($dsn, $user, $pass, [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION
    ]);
} catch (PDOException $e) {
    die("DB Connection failed: " . $e->getMessage());
}

// Handle force logout action
if (isset($_GET['force_logout'])) {
    $adminToLogout = (int)$_GET['force_logout'];

    // Prevent Super Admin from logging out themselves accidentally
    if ($adminToLogout === $_SESSION['admin_id']) {
        $message = "You cannot force logout yourself.";
    } else {
        $stmt = $pdo->prepare("UPDATE admins SET is_logged_in = 0 WHERE id = ?");
        $stmt->execute([$adminToLogout]);
        $message = "Admin ID $adminToLogout has been logged out.";
    }
}

// Fetch all logged-in admins
$stmt = $pdo->query("SELECT id, username, role FROM admins WHERE is_logged_in = 1 ORDER BY role, username");
$loggedInAdmins = $stmt->fetchAll(PDO::FETCH_ASSOC);

?>

<!DOCTYPE html>
<html>
<head>
    <title>Force Logout Admins - Super Admin</title>
</head>
<body>
    <h2>Force Logout Stuck Admins</h2>

    <?php if (!empty($message)): ?>
        <p style="color:green;"><?= htmlspecialchars($message) ?></p>
    <?php endif; ?>

    <?php if (count($loggedInAdmins) === 0): ?>
        <p>No admins are currently logged in.</p>
    <?php else: ?>
        <table border="1" cellpadding="8" cellspacing="0">
            <thead>
                <tr>
                    <th>Admin ID</th>
                    <th>Username</th>
                    <th>Role</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($loggedInAdmins as $admin): ?>
                    <tr>
                        <td><?= htmlspecialchars($admin['id']) ?></td>
                        <td><?= htmlspecialchars($admin['username']) ?></td>
                        <td><?= htmlspecialchars($admin['role']) ?></td>
                        <td>
                            <a href="?force_logout=<?= $admin['id'] ?>" onclick="return confirm('Force logout <?= htmlspecialchars($admin['username']) ?>?');">
                                Force Logout
                            </a>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    <?php endif; ?>

    <p><a href="admin_dashboard.php">Back to Dashboard</a></p>
</body>
</html>
