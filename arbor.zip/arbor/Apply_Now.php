<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: user_login.php");
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>Apply Now - Arbor Finance</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet" />
  <style>
    body { background-color: #e9ecef; }
    .navbar { background-color: #3b6363; }
    .navbar-nav .nav-link { padding: .5rem 1rem; }
    .section { padding: 60px 0; }
    .form-step { display: none; }
    .form-step.active { display: block; }
    .is-invalid { border-color: #dc3545; }
  </style>
</head>
<body>

<?php include 'navigation.php'; ?>

<section class="section text-center">
  <div class="container">
    <h2 class="mb-5">Loan Application</h2>
    <div class="row justify-content-center">
      <div class="col-md-8">
        <form id="loanForm"
              action="submit_loan.php"
              method="post"
              enctype="multipart/form-data"
              onsubmit="return calculateLoan(event)">

          <!-- Step 1: Personal Details -->
          <div class="form-step active" id="step1">
            <h5 class="text-start">Personal Details</h5>
            <input name="fullName"      id="fullName"      type="text"  class="form-control mb-3" placeholder="Full Name"              required pattern="[A-Za-z\s]+" />
            <input name="email"         id="email"         type="email" class="form-control mb-3" placeholder="Email Address"          required />
            <input name="phone"         id="phone"         type="tel"   class="form-control mb-3" placeholder="Phone Number"           required pattern="\d+" />
            <input name="nrc"           id="nrc"           type="text"  class="form-control mb-3" placeholder="NRC Number"             required pattern="\d{6}/\d{2}/\d" />
            <input name="homeAddress"   id="homeAddress"   type="text"  class="form-control mb-3" placeholder="Current Home Address"   required />
            <input name="location"      id="location"      type="text"  class="form-control mb-3" placeholder="Current Location"       required />
            <input name="occupation"    id="occupation"    type="text"  class="form-control mb-3" placeholder="Occupation"             required pattern="[A-Za-z\s]+" />
            <input name="institution"   id="institution"   type="text"  class="form-control mb-3" placeholder="Institution/Company"    required />
            <input name="bankName"      id="bankName"      type="text"  class="form-control mb-3" placeholder="Bank Name"              required pattern="[A-Za-z\s]+" />
            <input name="accountNumber" id="accountNumber" type="text"  class="form-control mb-3" placeholder="Bank Account Number"    required pattern="\d+" />
            <div class="d-flex justify-content-end">
              <button type="button" class="btn btn-primary" onclick="nextStep(1,2)">Next</button>
            </div>
          </div>

          <!-- Step 2: Next of Kin -->
          <div class="form-step" id="step2">
            <h5 class="text-start">Next of Kin Details</h5>
            <input name="kinName"        id="kinName"        type="text" class="form-control mb-3" placeholder="Full Name"            required pattern="[A-Za-z\s]+" />
            <input name="kinPhone"       id="kinPhone"       type="tel"  class="form-control mb-3" placeholder="Phone Number"         required pattern="\d+" />
            <input name="kinAddress"     id="kinAddress"     type="text" class="form-control mb-3" placeholder="Home Address"         required />
            <input name="kinLocation"    id="kinLocation"    type="text" class="form-control mb-3" placeholder="Location"             required />
            <input name="kinOccupation"  id="kinOccupation"  type="text" class="form-control mb-3" placeholder="Occupation"           required pattern="[A-Za-z\s]+" />
            <input name="kinInstitution" id="kinInstitution" type="text" class="form-control mb-3" placeholder="Institution/Company"  required />
            <input name="kinNrc"         id="kinNrc"         type="text" class="form-control mb-3" placeholder="NRC Number"           required pattern="\d{6}/\d{2}/\d" />
            <div class="d-flex justify-content-between">
              <button type="button" class="btn btn-secondary" onclick="nextStep(2,1)">Back</button>
              <button type="button" class="btn btn-primary"   onclick="nextStep(2,3)">Next</button>
            </div>
          </div>

          <!-- Step 3: Loan Details -->
          <div class="form-step" id="step3">
            <h5 class="text-start">Loan Details</h5>
            <label>Loan Amount (ZMW)</label>
            <input name="loanAmount" id="loanAmount" type="number" class="form-control mb-3" placeholder="Min 300" min="300" required />

            <label>Interest Rate (%)</label>
            <input name="interestRate" id="interestRate" type="number" class="form-control mb-3" readonly value="30" />

            <label>Loan Term (months)</label>
            <input name="loanTerm" id="loanTerm" type="number" class="form-control mb-3" placeholder="Term in months" required />

            <label>Loan Type</label>
            <select name="loanType" id="loanType" class="form-control mb-3">
              <option value="short">Short Term</option>
              <option value="long">Long Term</option>
            </select>

            <label>Loan Date</label>
            <input name="loanDate" id="loanDate" type="date" class="form-control mb-3" required />

            <label>Upload Payment Slips (Most Recent)</label>
            <input name="paymentSlip[]" id="paymentSlip" type="file" class="form-control mb-3" accept=".pdf,.jpg,.jpeg,.png" multiple required />

            <label>Upload NRC Front</label>
            <input name="nrc_front" id="nrc_front" type="file" class="form-control mb-3" accept=".jpg,.jpeg,.png" required />

            <label>Upload NRC Back</label>
            <input name="nrc_back" id="nrc_back" type="file" class="form-control mb-3" accept=".jpg,.jpeg,.png" required />

            <div class="d-flex justify-content-between">
              <button type="button" class="btn btn-secondary" onclick="nextStep(3,2)">Back</button>
              <button type="submit" class="btn btn-success">Apply for Loan</button>
            </div>

            <div id="results" class="mt-4" style="display:none; text-align:left;">
              <p><strong>Days Passed:</strong> <span id="daysPassed"></span></p>
              <p><strong>Interest:</strong> ZMW <span id="interestAmount"></span></p>
              <p><strong>Penalty:</strong> ZMW <span id="penaltyAmount"></span></p>
              <p><strong>Total Repayment:</strong> ZMW <span id="totalRepayment"></span></p>
              <p><strong>Monthly Repayment:</strong> ZMW <span id="monthlyRepayment"></span></p>
            </div>
          </div>

        </form>
      </div>
    </div>
  </div>
</section>

<footer class="text-white text-center py-4" style="background:#3b6363;">
  <div class="container">&copy; 2025 Arbor Finance. All rights reserved.</div>
</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script>
function nextStep(curr, next) {
  const step = document.getElementById(`step${curr}`);
  const inputs = step.querySelectorAll('input, select');
  let valid = true;
  inputs.forEach(i => {
    if (!i.checkValidity()) { i.classList.add('is-invalid'); valid = false; }
    else { i.classList.remove('is-invalid'); }
  });
  if (!valid) return;
  document.querySelectorAll('.form-step').forEach(s => s.classList.remove('active'));
  document.getElementById(`step${next}`).classList.add('active');
}

function calculateLoan(e) {
  const loanDate = new Date(document.getElementById('loanDate').value);
  const today = new Date();
  const days = Math.floor((today - loanDate)/(24*60*60*1000));
  const amt = parseFloat(document.getElementById('loanAmount').value);
  const ir  = parseFloat(document.getElementById('interestRate').value);
  const term= parseInt(document.getElementById('loanTerm').value,10);
  const interest = (amt*ir)/100;
  const penalty  = days>30 ? (days-30)*10 : 0;
  const total    = amt+interest+penalty;
  document.getElementById('daysPassed').innerText      = days;
  document.getElementById('interestAmount').innerText  = interest.toFixed(2);
  document.getElementById('penaltyAmount').innerText   = penalty.toFixed(2);
  document.getElementById('totalRepayment').innerText  = total.toFixed(2);
  document.getElementById('monthlyRepayment').innerText= (total/term).toFixed(2);
  document.getElementById('results').style.display     = 'block';
  return true;
}
</script>

</body>
</html>
