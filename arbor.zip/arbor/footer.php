<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>Arbor Finance Footer with Quick Links & FAQ</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet" />
  <style>
    footer {
      background: #3b6363;
      color: white;
    }
    footer a {
      color: #ffffff;
      text-decoration: none;
    }
    footer a:hover {
      text-decoration: underline;
    }
    .footer-bottom {
      border-top: 1px solid rgba(255,255,255,0.2);
      margin-top: 20px;
      padding-top: 10px;
    }
  </style>
</head>
<body>

  <!-- Footer -->
  <footer class="text-white pt-4 pb-2">
    <div class="container">
      <div class="row">

        <!-- Quick Links -->
        <div class="col-md-4 mb-3">
          <h5>Quick Links</h5>
          <ul class="list-unstyled">
            <li><a href="index.php">Home</a></li>
            <li><a href="#about">About Us</a></li>
            <li><a href="#features">Why Choose Us</a></li>
            <li><a href="loan_application.php">Apply for a Loan</a></li>
            <li><a href="contact.php">Contact</a></li>
          </ul>
        </div>

        <!-- Contact -->
        <div class="col-md-4 mb-3">
          <h5>Contact Us</h5>
          <p><strong>Address:</strong> Plot 10, Independence Avenue, Lusaka, Zambia</p>
          <p><strong>Email:</strong> info@arborfinance.com</p>
          <p><strong>Phone:</strong> +260 971 234 567</p>
        </div>
      </div>

      <!-- Footer Bottom -->
      <div class="text-center footer-bottom">
        <p class="mb-0">&copy; 2025 Arbor Finance. All rights reserved.</p>
        <p class="mb-0">Designed by Raphael Mulangi.</p>
      </div>
    </div>
  </footer>

  <!-- Bootstrap JS Bundle -->
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

</body>
</html>
