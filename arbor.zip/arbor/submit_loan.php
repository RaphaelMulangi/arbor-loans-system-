<?php
$mysqli = new mysqli("localhost", "root", "", "arbor");
if ($mysqli->connect_error) {
    die("❌ Connection failed: " . $mysqli->connect_error);
}

// Use transaction for atomicity
$mysqli->begin_transaction();

function sanitizeFileName($prefix, $originalName) {
    return time() . "_{$prefix}_" . preg_replace("/[^A-Za-z0-9\-_\.]/", "_", basename($originalName));
}

function uploadFile($file, $dir, $prefix) {
    if (!empty($file['tmp_name']) && is_uploaded_file($file['tmp_name'])) {
        if (!is_dir($dir)) {
            mkdir($dir, 0777, true);
        }
        $safeName = sanitizeFileName($prefix, $file['name']);
        $targetPath = $dir . $safeName;
        if (move_uploaded_file($file['tmp_name'], $targetPath)) {
            return $targetPath;
        }
    }
    return '';
}

// ========== File Uploads ==========
$paymentSlipPaths = [];

if (isset($_FILES['payment_slip']['tmp_name']) && is_array($_FILES['payment_slip']['tmp_name'])) {
    foreach ($_FILES['payment_slip']['tmp_name'] as $i => $tmp_name) {
        $file = [
            'tmp_name' => $tmp_name,
            'name' => $_FILES['payment_slip']['name'][$i]
        ];
        $path = uploadFile($file, "uploads/slips/", "slip");
        if ($path) {
            $paymentSlipPaths[] = $path;
        }
    }
}
$paymentSlipPath = implode(",", $paymentSlipPaths);

$nrcFrontPath = uploadFile($_FILES['nrc_front'], "uploads/nrc/", "nrc_front");
$nrcBackPath = uploadFile($_FILES['nrc_back'], "uploads/nrc/", "nrc_back");

// ========== Form Data ==========
$fullName = $_POST['fullName'] ?? '';
$email = $_POST['email'] ?? '';
$phone = $_POST['phone'] ?? '';
$nrc = $_POST['nrc'] ?? '';
$homeAddress = $_POST['homeAddress'] ?? '';
$location = $_POST['location'] ?? '';
$occupation = $_POST['occupation'] ?? '';
$institution = $_POST['institution'] ?? '';

$bankName = $_POST['bankName'] ?? '';
$accountNumber = $_POST['accountNumber'] ?? '';
$loanAmount = floatval($_POST['loanAmount'] ?? 0);
$interestRate = floatval($_POST['interestRate'] ?? 0);
$loanTerm = intval($_POST['loanTerm'] ?? 0);
$loanType = $_POST['loanType'] ?? '';
$loanDate = $_POST['loanDate'] ?? date('Y-m-d');

// Calculate due date (30 days after loan date)
$dueDate = date('Y-m-d', strtotime($loanDate . ' +30 days'));

$kinName = $_POST['kinName'] ?? '';
$kinPhone = $_POST['kinPhone'] ?? '';
$kinAddress = $_POST['kinAddress'] ?? '';
$kinLocation = $_POST['kinLocation'] ?? '';
$kinOccupation = $_POST['kinOccupation'] ?? '';
$kinInstitution = $_POST['kinInstitution'] ?? '';
$kinNrc = $_POST['kinNrc'] ?? '';

// ========== Insert into personaldetails ==========
$stmt1 = $mysqli->prepare("INSERT INTO personaldetails (full_name, email, phone, nrc, address, location, occupation, institution) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
$stmt1->bind_param("ssssssss", $fullName, $email, $phone, $nrc, $homeAddress, $location, $occupation, $institution);

if (!$stmt1->execute()) {
    $mysqli->rollback();
    die("❌ Error saving personal details: " . $stmt1->error);
}

$user_id = $stmt1->insert_id;
$stmt1->close();

// ========== Insert into loan_details ==========
$stmt2 = $mysqli->prepare("INSERT INTO loan_details (user_id, loan_amount, interest_rate, loan_term, type, date_applied, due_date, payment_slip, bank_name, account_number, nrc_front, nrc_back) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
$stmt2->bind_param("iddsssssssss", $user_id, $loanAmount, $interestRate, $loanTerm, $loanType, $loanDate, $dueDate, $paymentSlipPath, $bankName, $accountNumber, $nrcFrontPath, $nrcBackPath);

if (!$stmt2->execute()) {
    $mysqli->rollback();
    die("❌ Error saving loan details: " . $stmt2->error);
}

$loan_id = $stmt2->insert_id;
$stmt2->close();

// ========== Generate and update loan number ==========
$loan_number = "LOAN-" . date("Ymd") . "-" . str_pad($loan_id, 4, "0", STR_PAD_LEFT);
$stmt_update = $mysqli->prepare("UPDATE loan_details SET loan_number = ? WHERE id = ?");
$stmt_update->bind_param("si", $loan_number, $loan_id);

if (!$stmt_update->execute()) {
    $mysqli->rollback();
    die("❌ Error updating loan number: " . $stmt_update->error);
}
$stmt_update->close();

// ========== Insert into next_of_kin ==========
$stmt3 = $mysqli->prepare("INSERT INTO next_of_kin (loan_id, kin_name, kin_phone, kin_address, kin_location, kin_occupation, kin_institution, kin_nrc) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
$stmt3->bind_param("isssssss", $loan_id, $kinName, $kinPhone, $kinAddress, $kinLocation, $kinOccupation, $kinInstitution, $kinNrc);

if (!$stmt3->execute()) {
    $mysqli->rollback();
    die("❌ Error saving next of kin: " . $stmt3->error);
}
$stmt3->close();

// Commit all if everything succeeded
$mysqli->commit();

echo "<div class='alert alert-success'>✅ Loan application submitted successfully.<br>Your Loan Number is: <strong>$loan_number</strong></div>";
echo "<a href='index.php' class='btn btn-primary'>Back to Home</a>";

$mysqli->close();
?>
