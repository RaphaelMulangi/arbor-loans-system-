<?php
session_start();

if (isset($_SESSION['admin_id'])) {
    $adminId = $_SESSION['admin_id'];

    // DB connection (adjust settings)
    $host = 'localhost';
    $db = 'your_db_name';
    $user = 'your_db_user';
    $pass = 'your_db_pass';

    $dsn = "mysql:host=$host;dbname=$db;charset=utf8mb4";

    try {
        $pdo = new PDO($dsn, $user, $pass, [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION
        ]);
        // Mark admin as logged out
        $stmt = $pdo->prepare("UPDATE admins SET is_logged_in = 0 WHERE id = ?");
        $stmt->execute([$adminId]);
    } catch (PDOException $e) {
        // Optionally handle error
    }

    // Clear session
    session_unset();
    session_destroy();
}

header('Location: admin_login.php');
exit;
