<?php include 'navigation.php'; ?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>Services - Arbor Finance</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet" />
  <style>
    body {
      background-color: #e9ecef;
    }
    .service-card {
      border-radius: 10px;
      box-shadow: 0 4px 8px rgba(0,0,0,0.1);
      transition: transform 0.3s ease;
    }
    .service-card:hover {
      transform: translateY(-5px);
    }
    .service-icon {
      font-size: 50px;
      color: #3b6363;
      margin-bottom: 15px;
    }
  </style>
</head>
<body>

<section class="container py-5">
  <h2 class="text-center mb-5" style="color:#3b6363;">Our Services</h2>
  <div class="row g-4">
    <div class="col-md-4">
      <div class="card service-card p-4 text-center bg-white">
        <div class="service-icon">💳</div>
        <h5>Personal Loans</h5>
        <p>Flexible personal loans with quick approval and affordable rates.</p>
      </div>
    </div>
    <div class="col-md-4">
      <div class="card service-card p-4 text-center bg-white">
        <div class="service-icon">🏢</div>
        <h5>Business Financing</h5>
        <p>Support your business growth with tailored financial solutions.</p>
      </div>
    </div>
    <div class="col-md-4">
      <div class="card service-card p-4 text-center bg-white">
        <div class="service-icon">⚡</div>
        <h5>Short-term Advances</h5>
        <p>Quick cash advances for your urgent financial needs.</p>
      </div>
    </div>
    <div class="col-md-4">
      <div class="card service-card p-4 text-center bg-white">
        <div class="service-icon">💼</div>
        <h5>Business Consultancy</h5>
        <p>Expert guidance to help your business strategize, grow, and succeed.</p>
      </div>
    </div>
  </div>
</section>

<?php include 'footer.php'; ?>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
