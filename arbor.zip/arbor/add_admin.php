<?php
include __DIR__ . '/db_connection.php';
session_start();

if ($_SESSION['role'] !== 'super_admin') {
    header('Location: dashboard.php');
    exit();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = $_POST['name'];
    $email = $_POST['email'];
    $role = $_POST['role'];
    $status = $_POST['status'];
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT);

    $stmt = $conn->prepare("INSERT INTO admins (name, email, role, status, password) VALUES (?, ?, ?, ?, ?)");
    $stmt->bind_param("sssss", $name, $email, $role, $status, $password);

    if ($stmt->execute()) {
        logAdminAction($_SESSION['admin_id'], 'Add Admin', "Added new admin: $name ($email)");
        header('Location: user_admin.php?msg=Admin added');
    } else {
        echo "Error: " . $stmt->error;
    }
}
?>

<!-- Basic form -->
<form method="POST">
    <h2>Add Admin</h2>
    <input type="text" name="name" placeholder="Name" required>
    <input type="email" name="email" placeholder="Email" required>
    <select name="role">
        <option value="admin">Admin</option>
        <option value="super_admin">Super Admin</option>
    </select>
    <select name="status">
        <option value="active">Active</option>
        <option value="inactive">Inactive</option>
    </select>
    <input type="password" name="password" placeholder="Password" required>
    <button type="submit">Create Admin</button>
</form>
