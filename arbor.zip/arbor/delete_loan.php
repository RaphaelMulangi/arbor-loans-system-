<?php
include __DIR__ . '/db_connection.php';

$loans = [];
$successMsg = '';
$errorMsg = '';

// Fetch all loans with user info
try {
    $stmt = $pdo->query("SELECT l.id, p.full_name, l.loan_amount, l.status 
                         FROM loan_details l
                         JOIN personaldetails p ON p.id = l.id
                         ORDER BY date_applied DESC");
    $loans = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    $errorMsg = "DB Error: " . $e->getMessage();
}

// Handle delete
if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST['loan_id'])) {
    $loanId = $_POST['loan_id'];
    try {
        $stmt = $pdo->prepare("DELETE FROM loan_details WHERE id = ?");
        $stmt->execute([$loanId]);
        $successMsg = "Loan ID $loanId deleted successfully.";
        header("Refresh:1"); // Refresh page to reflect deletion
    } catch (PDOException $e) {
        $errorMsg = "Failed to delete: " . $e->getMessage();
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Delete Loans - Arbor Finance</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <style>
    body { background-color: #f4f4f4; }
    .container { margin-top: 50px; }
    .table thead th {
      position: sticky;
      top: 0;
      background-color: #343a40;
      color: white;
    }
  </style>
</head>
<body>

<div class="container">
  <div class="bg-white p-4 rounded shadow">
    <h3 class="mb-4">Delete Loan Applications</h3>

    <?php if ($successMsg): ?>
      <div class="alert alert-success"><?= $successMsg ?></div>
    <?php elseif ($errorMsg): ?>
      <div class="alert alert-danger"><?= $errorMsg ?></div>
    <?php endif; ?>

    <table class="table table-bordered table-striped">
      <thead>
        <tr>
          <th>#</th>
          <th>Full Name</th>
          <th>Loan Amount</th>
          <th>Status</th>
          <th>Action</th>
        </tr>
      </thead>
      <tbody>
        <?php foreach ($loans as $index => $loan): ?>
        <tr>
          <td><?= $index + 1 ?></td>
          <td><?= htmlspecialchars($loan['full_name']) ?></td>
          <td>ZMW <?= number_format($loan['loan_amount'], 2) ?></td>
          <td><?= ucfirst($loan['status']) ?></td>
          <td>
            <form method="POST" onsubmit="return confirm('Are you sure you want to delete this loan?');">
              <input type="hidden" name="loan_id" value="<?= $loan['id'] ?>">
              <button type="submit" class="btn btn-sm btn-danger">Delete</button>
            </form>
          </td>
        </tr>
        <?php endforeach; ?>
        <?php if (empty($loans)): ?>
        <tr><td colspan="5" class="text-center">No loan records found.</td></tr>
        <?php endif; ?>
      </tbody>
    </table>

    <a href="admin_dashboard.php" class="btn btn-secondary mt-3">Back to Dashboard</a>
  </div>
</div>

</body>
</html>
