<?php include 'navigation.php'; ?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>About Us - Arbor Finance</title>

  <!-- Bootstrap CSS -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">

  <style>
  body {
    background-color: #f9fafb;
    color: #374151;
    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
  }

  main {
    max-width: 1100px;
    margin: 0 auto;
    padding: 4rem 1rem;
  }

  h2, h4, h5 {
    color: #047857;
  }

  h2 {
    font-size: 2.25rem;
    font-weight: 700;
    margin-bottom: 1rem;
  }

  h4 {
    font-size: 1.5rem;
    font-weight: 600;
    margin-top: 2rem;
    margin-bottom: 1rem;
  }

  h5 {
    font-size: 1.25rem;
    font-weight: 500;
    margin-top: 1.5rem;
    margin-bottom: 0.5rem;
  }

  p {
    font-size: 1.125rem;
    line-height: 1.75;
    margin-bottom: 1rem;
  }

  .mb-12
  {
    background: rgba(0,0,0,.8);
    border-radius: 1rem;
    padding: 15px;
  }

  .mb-12 li
  {
    color: #ffffff;
  }

  ul.list-disc {
    padding-left: 1.5rem;
    font-size: 1.125rem;
    line-height: 1.75;
  }

  ul.list-disc li::marker {
    color: #047857;
    font-size: 1.2rem;
  }

  a {
    color: #059669;
    text-decoration: none;
    font-weight: 500;
  }

  a:hover {
    text-decoration: underline;
    color: #047857;
  }

  /* Section layout */
  section {
    margin-bottom: 4rem;
  }

  .row.align-items-center {
    display: flex;
    flex-wrap: wrap;
    gap: 2rem;
    justify-content: center;
  }

  .row.align-items-center > div {
    flex: 1 1 100%;
    text-align: center;
  }

  @media (min-width: 768px) {
    .row.align-items-center > div {
      flex: 1;
      text-align: left;
    }

    .row.align-items-center .col-md-5 {
      display: flex;
      justify-content: center;
    }
  }

  /* Images */
  .img-fluid {
    border-radius: 1rem;
    box-shadow: 0 8px 24px rgba(0, 0, 0, 0.08);
    transition: transform 0.3s ease, box-shadow 0.3s ease;
    max-width: 100%;
    height: auto;
  }

  .img-fluid:hover {
    transform: scale(1.03);
    box-shadow: 0 12px 32px rgba(0, 0, 0, 0.15);
  }

  /* Footer */
  footer {
    font-size: 0.95rem;
    color: #6b7280;
    padding-top: 1rem;
    border-top: 1px solid #e5e7eb;
  }

  @media (max-width: 768px) {
    h2 {
      font-size: 1.75rem;
    }

    p, ul.list-disc {
      font-size: 1rem;
    }
  }
</style>


</head>
<body class="bg-gray-50 text-gray-800" style="background: url('img/about.jpg') no-repeat; background-size: cover; background-position: center;">

  <!-- Main Content -->
  <main class="max-w-5xl mx-auto px-4 py-10">
    
    <!-- Who We Are with image on right -->
    <section class="mb-12">
      <div class="row align-items-center">
        <div class="col-md-7">
          <h2 class="text-3xl font-bold mb-4 text-green-700" style="text-align: center; color: #F15E22;">Who We Are</h2>
          <p class="text-lg leading-relaxed" style="text-align: center; padding-left: 2rem; color: #ffffff">
            Arbor Finance is a committed microfinance institution focused on providing fast, affordable, and accessible financial solutions tailored to the needs of individuals and small businesses. We strive to bridge the financial gap by offering flexible lending options that empower our clients to meet their personal or business goals with confidence and ease.
          </p>
        </div>
        <div class="col-md-5">
          <img src="img/who we are.png" alt="Who We Are" class="img-fluid rounded shadow" />
        </div>
      </div>
    </section>

    <!-- Our Mission with image on right -->
    <section class="mb-12">
      <div class="row align-items-center">
        <div class="col-md-7">
          <h2 class="text-2xl font-semibold mb-3 text-green-700" style="text-align: center; color: #F15E22;">Our Mission</h2>
          <p class="text-lg leading-relaxed" style="text-align: center; padding-left: 2rem; color: #ffffff">
            Our mission is to empower our clients by offering personalized loan services and innovative financial products that support their financial growth and long-term stability. We are dedicated to understanding the unique needs of each client and providing solutions that not only address immediate financial challenges but also promote sustainable economic progress.
          </p>
        </div>
        <div class="col-md-5">
          <img src="img/ourmission.png" alt="Our Mission" class="img-fluid rounded shadow" />
        </div>
      </div>
    </section>

    <!-- Our Vision with image on right -->
    <section class="mb-12">
      <div class="row align-items-center">
        <div class="col-md-7">
          <h2 class="text-2xl font-semibold mb-3 text-green-700" style="text-align: center; color: #F15E22;">Our Vision</h2>
          <p class="text-lg leading-relaxed" style="text-align: center; padding-left: 2rem; color: #ffffff">
            Our vision is to become a leading microfinance institution in Zambia, widely recognized for our reliability, positive impact on communities, and unwavering commitment to promoting financial inclusion. We aim to be a trusted financial partner that contributes meaningfully to economic empowerment by making financial services accessible to everyone, especially underserved populations.
          </p>
        </div>
        <div class="col-md-5">
          <img src="img/our vision.png" alt="Our Vision" class="img-fluid rounded shadow" />
        </div>
      </div>
    </section>

    <!-- Why Choose Us? -->
    <section class="mb-12">
      <h2 class="text-2xl font-semibold mb-3 text-green-700" style="text-align: center; color: #F15E22;">Why Choose Us?</h2>
      <ul class="list-disc pl-6 text-lg space-y-2">
        <li>Quick and easy loan approvals</li>
        <li>Transparent interest rates with no hidden fees</li>
        <li>Friendly and professional customer service</li>
        <li>Flexible repayment options</li>
        <li>Commitment to community empowerment</li>
      </ul>
    </section>

    <!-- Additional info from your snippet -->
    <section class="mb-12">
      <h4 class="text-green-700" style="text-align: center; color: #F15E22;">What We Do</h4>
      <p  style="text-align: center; padding-left: 2rem; color: #ffffff">
        At Arbor Finance, we are committed to empowering individuals and businesses by providing flexible and accessible financial solutions. Whether you're looking for personal loans, business financing, or short-term cash advances, our services are tailored to meet your needs quickly and securely.
      </p>


      <h5 class="mt-4" style="text-align: center; color: #F15E22;">Need Help?</h5>
      <p  style="text-align: center; padding-left: 2rem; color: #ffffff">Reach us via our <a href="Contact.php">Contact Page</a> — we're here to assist you.</p>
    </section>
  </main>

  <!-- Footer -->
  <footer class="text-center mt-5 mb-4">
    <?php include 'footer.php'; ?>
  </footer>

  <!-- Bootstrap JS -->
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>


