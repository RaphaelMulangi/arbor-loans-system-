<?php
include __DIR__ . '/db_connection.php';

$approvedLoans = [];

try {
    $stmt = $pdo->query("SELECT l.id, p.full_name, p.phone, p.email, l.loan_amount 
                         FROM loan_details l
                         JOIN personaldetails p ON p.id = l.user_id
                         WHERE l.status = 'approved'
                         ORDER BY date_applied DESC");
    $approvedLoans = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    die("DB Error: " . $e->getMessage());
}

// If download requested
if (isset($_POST['download'])) {
    $filename = "approved_loans_messages.txt";

    $content = "Loan Approval Messages - Arbor Finance\n\n";
    foreach ($approvedLoans as $loan) {
        $content .= "Dear " . $loan['full_name'] . ",\n";
        $content .= "Congratulations! Your loan application for ZMW " . number_format($loan['loan_amount'], 2) . " has been approved.\n";
        $content .= "Contact: Phone - " . $loan['phone'] . ", Email - " . $loan['email'] . "\n";
        $content .= "Please visit our office or check your portal for next steps.\n\n";
    }

    header('Content-Type: text/plain');
    header('Content-Disposition: attachment; filename="' . $filename . '"');
    echo $content;
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Export Approval Messages - Arbor Finance</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <style>
    body { background-color: #f4f4f4; margin: 0; padding: 0; }
    .container { margin-top: 50px; }
    .bg-custom { background-color: white; padding: 30px; border-radius: 8px; box-shadow: 0 4px 10px rgba(0,0,0,0.1); }
    .scroll-table { max-height: 400px; overflow-y: auto; }
    footer { width: 100%; }
  </style>
</head>
<body>

<div class="container">
  <div class="bg-custom">
    <h3 class="mb-4">Export Loan Approval Messages</h3>

    <?php if (count($approvedLoans) > 0): ?>
      <form method="POST">
        <button type="submit" name="download" class="btn btn-success mb-3">Download Messages (.txt)</button>
      </form>

      <div class="scroll-table">
        <table class="table table-bordered table-striped">
          <thead class="table-dark">
            <tr>
              <th>#</th>
              <th>Full Name</th>
              <th>Loan Amount</th>
              <th>Phone</th>
              <th>Email</th>
              <th>Approval Message</th>
            </tr>
          </thead>
          <tbody>
            <?php foreach ($approvedLoans as $i => $loan): ?>
            <tr>
              <td><?= $i + 1 ?></td>
              <td><?= htmlspecialchars($loan['full_name']) ?></td>
              <td>ZMW <?= number_format($loan['loan_amount'], 2) ?></td>
              <td><?= htmlspecialchars($loan['phone']) ?></td>
              <td><?= htmlspecialchars($loan['email']) ?></td>
              <td>
                Dear <?= htmlspecialchars($loan['full_name']) ?>,<br/>
                Congratulations! Your loan for ZMW <?= number_format($loan['loan_amount'], 2) ?> has been approved.<br/>
                Please check your portal for next steps.
              </td>
            </tr>
            <?php endforeach; ?>
          </tbody>
        </table>
      </div>
    <?php else: ?>
      <div class="alert alert-warning">
        No approved loans found to export.
      </div>
    <?php endif; ?>

    <div class="my-4 text-center">
      <a href="Admin_dashboard.php" class="btn btn-outline-secondary">← Back to Dashboard</a>
    </div>
  </div>
</div>

<!-- Footer outside main container to span full width -->
<?php include 'footer.php'; ?>

</body>
</html>
