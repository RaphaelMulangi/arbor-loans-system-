<?php include 'navigation.php'; ?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>Admin Registration - Arbor Finance</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <style>
    body {
      background-color: #f8f9fa;
    }
    .register-container {
      max-width: 450px;
      margin: 100px auto;
      padding: 30px;
      background-color: #fff;
      border-radius: 8px;
      box-shadow: 0 4px 10px rgba(0,0,0,0.1);
    }
  </style>
</head>
<body>

<div class="register-container">
  <h3 class="text-center mb-4">Register New Admin</h3>
  <form action="process_admin_register.php" method="POST">
    <div class="mb-3">
      <label class="form-label">Username</label>
      <input type="text" name="username" class="form-control" required>
    </div>

    <div class="mb-3">
      <label class="form-label">Email</label>
      <input type="email" name="email" class="form-control" required>
    </div>

    <div class="mb-3">
      <label class="form-label">Password</label>
      <input type="password" name="password" class="form-control" required>
    </div>

    <div class="mb-3">
      <label class="form-label">Confirm Password</label>
      <input type="password" name="confirm_password" class="form-control" required>
    </div>

    <div class="mb-3">
      <label class="form-label">Admin Role</label>
      <select name="role" class="form-select" required>
        <option value="" disabled selected>Select a role</option>
        <option value="1">Super Admin</option>
        <option value="2">Loan Approver</option>
        <option value="3">Loan Viewer</option>
        <option value="4">Loan Constant</option>
      </select>
    </div>

    <?php if (isset($_GET['message'])): ?>
      <div class="alert alert-info text-center">
        <?= htmlspecialchars($_GET['message']) ?>
      </div>
    <?php endif; ?>

    <button type="submit" class="btn btn-success w-100 mb-2">Register</button>
    <a href="admin_login.php" class="btn btn-secondary w-100">Back to Login</a>
  </form>
</div>

<?php include 'footer.php'; ?>
</body>
</html>