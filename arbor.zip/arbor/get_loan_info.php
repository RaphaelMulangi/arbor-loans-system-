<?php
include 'db_connection.php';

if (isset($_GET['loan_number'])) {
    $loan_number = $_GET['loan_number'];

    $query = "
        SELECT 
            pd.full_name,
            ld.loan_amount + (ld.loan_amount * ld.interest_rate / 100) AS total_due,
            ld.loan_amount / ld.loan_term AS monthly,
            ld.remaining_balance
        FROM loan_details ld
        JOIN personaldetails pd ON ld.personal_id = pd.id
        WHERE ld.loan_verification_number = ?
    ";

    $stmt = $conn->prepare($query);
    $stmt->bind_param("s", $loan_number);
    $stmt->execute();
    $stmt->bind_result($fullName, $totalDue, $monthly, $balance);

    if ($stmt->fetch()) {
        echo json_encode([
            'fullName' => $fullName,
            'totalDue' => round($totalDue, 2),
            'monthly' => round($monthly, 2),
            'balance' => round($balance, 2)
        ]);
    } else {
        echo json_encode(['error' => 'Loan not found.']);
    }

    $stmt->close();
    $conn->close();
}
?>
