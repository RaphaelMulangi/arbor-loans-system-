<?php
$mysqli = new mysqli("localhost", "root", "", "arbor");

if ($mysqli->connect_errno) {
    die("Failed to connect to MySQL: (" . $mysqli->connect_errno . ") " . $mysqli->connect_error);
}

// Allowed filters
$allowedReportTypes = ['daily', 'weekly', 'monthly'];
$allowedStatusFilters = ['paid', 'missed', 'current'];

// Sanitize inputs
$reportType = isset($_GET['report_type']) && in_array($_GET['report_type'], $allowedReportTypes) ? $_GET['report_type'] : '';
$statusFilter = isset($_GET['status_filter']) && in_array($_GET['status_filter'], $allowedStatusFilters) ? $_GET['status_filter'] : '';

// Build WHERE clause starting without approval_status filter
$where = " WHERE 1=1 ";

// Apply report type filter
if ($reportType) {
    switch ($reportType) {
        case 'daily':
            $where .= " AND loan_details.date_applied >= NOW() - INTERVAL 1 DAY ";
            break;
        case 'weekly':
            $where .= " AND loan_details.date_applied >= NOW() - INTERVAL 7 DAY ";
            break;
        case 'monthly':
            $where .= " AND loan_details.date_applied >= NOW() - INTERVAL 30 DAY ";
            break;
    }
}

// Apply status filter
if ($statusFilter) {
    switch ($statusFilter) {
        case 'paid':
            $where .= " AND loan_details.repayment_status = 'paid' ";
            break;
        case 'missed': // overdue and unpaid
            $where .= " AND loan_details.due_date < CURDATE() AND loan_details.repayment_status != 'paid' ";
            break;
        case 'current': // not overdue and unpaid
            $where .= " AND (loan_details.due_date >= CURDATE() OR loan_details.due_date IS NULL) AND loan_details.repayment_status != 'paid' ";
            break;
    }
}

$sql = "
    SELECT 
        loan_details.id, 
        personaldetails.full_name, 
        loan_details.loan_amount, 
        loan_details.repayment_status, 
        loan_details.due_date, 
        loan_details.date_applied 
    FROM loan_details 
    JOIN personaldetails ON loan_details.user_id = personaldetails.id
    $where 
    ORDER BY loan_details.date_applied DESC
";

$result = $mysqli->query($sql);
if (!$result) {
    die("Error running query: " . $mysqli->error);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <title>Loan Reports Dashboard</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet" />
</head>
<body>
<div class="container my-5">
    <h2 class="mb-4">Loan Reports Dashboard</h2>

    <form method="GET" class="row g-3 mb-4 align-items-center">
        <div class="col-md-3">
            <select name="report_type" class="form-select" onchange="this.form.submit()">
                <option value="">-- Select Report Type --</option>
                <option value="daily" <?= ($reportType === 'daily') ? 'selected' : '' ?>>Daily</option>
                <option value="weekly" <?= ($reportType === 'weekly') ? 'selected' : '' ?>>Weekly</option>
                <option value="monthly" <?= ($reportType === 'monthly') ? 'selected' : '' ?>>Monthly</option>
            </select>
        </div>

        <div class="col-md-3">
            <select name="status_filter" class="form-select" onchange="this.form.submit()">
                <option value="">-- Filter by Status --</option>
                <option value="missed" <?= ($statusFilter === 'missed') ? 'selected' : '' ?>>Missed (Overdue)</option>
                <option value="paid" <?= ($statusFilter === 'paid') ? 'selected' : '' ?>>Paid</option>
                <option value="current" <?= ($statusFilter === 'current') ? 'selected' : '' ?>>Current</option>
            </select>
        </div>

        <div class="col-md-3">
            <a href="generate_report.php?report_type=<?= urlencode($reportType) ?>&status_filter=<?= urlencode($statusFilter) ?>" class="btn btn-primary">
                Download PDF
            </a>
        </div>
    </form>

    <table class="table table-striped table-bordered">
        <thead class="table-dark">
            <tr>
                <th>Loan ID</th>
                <th>Full Name</th>
                <th>Amount</th>
                <th>Status</th>
                <th>Due Date</th>
                <th>Date Applied</th>
            </tr>
        </thead>
        <tbody>
        <?php if ($result->num_rows > 0): ?>
            <?php while ($row = $result->fetch_assoc()): ?>
                <tr>
                    <td><?= htmlspecialchars($row['id']) ?></td>
                    <td><?= htmlspecialchars($row['full_name']) ?></td>
                    <td><?= number_format($row['loan_amount'], 2) ?></td>
                    <td><?= ucfirst(htmlspecialchars($row['repayment_status'])) ?></td>
                    <td><?= !empty($row['due_date']) ? htmlspecialchars($row['due_date']) : '<em>Not Set</em>' ?></td>
                    <td><?= htmlspecialchars($row['date_applied']) ?></td>
                </tr>
            <?php endwhile; ?>
        <?php else: ?>
            <tr><td colspan="6" class="text-center">No records found.</td></tr>
        <?php endif; ?>
        </tbody>
    </table>

    <div class="text-center mt-4">
        <a href="admin_dashboard.php" class="btn btn-secondary">Back to Dashboard</a>
    </div>
</div>

<footer class="text-center mt-5 mb-4">
    <?php include 'footer.php'; ?>
</footer>
</body>
</html>
