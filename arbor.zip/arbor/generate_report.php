<?php
require('fpdf186/fpdf.php'); // Adjust if your FPDF is in a different folder

$mysqli = new mysqli("localhost", "root", "", "arbor");
if ($mysqli->connect_errno) {
    die("Database connection failed: " . $mysqli->connect_error);
}

// Validate filters
$allowedReportTypes = ['daily', 'weekly', 'monthly'];
$allowedStatusFilters = ['overdue', 'paid', 'unpaid'];

$reportType = isset($_GET['report_type']) && in_array($_GET['report_type'], $allowedReportTypes) ? $_GET['report_type'] : '';
$statusFilter = isset($_GET['status_filter']) && in_array($_GET['status_filter'], $allowedStatusFilters) ? $_GET['status_filter'] : '';

// Build WHERE clause
$where = " WHERE 1=1 ";

switch ($reportType) {
    case 'daily':
        $where .= " AND loan_details.date_applied >= NOW() - INTERVAL 1 DAY ";
        break;
    case 'weekly':
        $where .= " AND loan_details.date_applied >= NOW() - INTERVAL 7 DAY ";
        break;
    case 'monthly':
        $where .= " AND loan_details.date_applied >= NOW() - INTERVAL 30 DAY ";
        break;
}

if (!empty($statusFilter)) {
    switch ($statusFilter) {
        case 'overdue':
            $where .= " AND loan_details.due_date < CURDATE() AND loan_details.repayment_status != 'paid' ";
            break;
        case 'paid':
            $where .= " AND loan_details.repayment_status = 'paid' ";
            break;
        case 'unpaid':
            $where .= " AND loan_details.repayment_status != 'paid' ";
            break;
    }
}

// Fetch data
$sql = "
    SELECT 
        loan_details.id, 
        personaldetails.full_name, 
        loan_details.loan_amount, 
        loan_details.repayment_status, 
        loan_details.due_date, 
        loan_details.date_applied 
    FROM loan_details 
    JOIN personaldetails ON loan_details.user_id = personaldetails.id
    $where
    ORDER BY loan_details.date_applied DESC
";

$result = $mysqli->query($sql);
if (!$result) {
    die("Query error: " . $mysqli->error);
}

// PDF setup
class PDF extends FPDF {
    function Header() {
        global $reportType, $statusFilter;

        // Logo (optional - adjust path and position)
        $this->Image('img/arbor_Logo.png', 10, 6, 25); // Replace 'logo.png' with your logo
        $this->SetFont('Arial', 'B', 14);
        $this->Cell(0, 10, 'Loan Report - ' . ucfirst($reportType) . ' (' . ucfirst($statusFilter) . ')', 0, 1, 'C');
        $this->Ln(5);

        // Table headers
        $this->SetFont('Arial', 'B', 10);
        $this->Cell(20, 10, 'Loan ID', 1);
        $this->Cell(50, 10, 'Full Name', 1);
        $this->Cell(25, 10, 'Amount', 1);
        $this->Cell(25, 10, 'Status', 1);
        $this->Cell(35, 10, 'Due Date', 1);
        $this->Cell(35, 10, 'Date Applied', 1);
        $this->Ln();
    }

    function Footer() {
        $this->SetY(-15);
        $this->SetFont('Arial', 'I', 8);
        $this->Cell(0, 10, 'Generated on ' . date('Y-m-d H:i:s'), 0, 0, 'C');
    }
}

$pdf = new PDF();
$pdf->AddPage();
$pdf->SetFont('Arial', '', 10);

$totalLoanAmount = 0;
if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $pdf->Cell(20, 10, $row['id'], 1);
        $pdf->Cell(50, 10, $row['full_name'], 1);
        $pdf->Cell(25, 10, number_format($row['loan_amount'], 2), 1);
        $pdf->Cell(25, 10, ucfirst($row['repayment_status']), 1);
        $pdf->Cell(35, 10, $row['due_date'], 1);
        $pdf->Cell(35, 10, $row['date_applied'], 1);
        $pdf->Ln();
        $totalLoanAmount += $row['loan_amount'];
    }

    // Total row
    $pdf->SetFont('Arial', 'B', 10);
    $pdf->Cell(70, 10, 'Total Loans', 1);
    $pdf->Cell(25, 10, number_format($totalLoanAmount, 2), 1);
    $pdf->Cell(105, 10, '', 1); // empty cells for the rest
} else {
    $pdf->Cell(0, 10, 'No records found.', 1, 1, 'C');
}

$filename = 'Loan_Report_' . ucfirst($reportType) . '_' . ucfirst($statusFilter) . '.pdf';
$pdf->Output('D', $filename);
exit;
?>
