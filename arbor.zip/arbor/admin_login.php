<?php
session_start();

// If already logged in, redirect to dashboard
if (isset($_SESSION['admin_id'])) {
    header('Location: admin_dashboard.php');
    exit;
}

// DB connection
$host = 'localhost';
$db   = 'arbor';
$user = 'root';
$pass = '';
$dsn = "mysql:host=$host;dbname=$db;charset=utf8mb4";

try {
    $pdo = new PDO($dsn, $user, $pass, [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION
    ]);
} catch (PDOException $e) {
    die("DB Connection failed: " . $e->getMessage());
}

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';
    $submittedRole = $_POST['role'] ?? '';

    if ($username === '' || $password === '' || $submittedRole === '') {
        $error = "Please fill in all fields.";
    } else {
        // Corrected SELECT query
        $stmt = $pdo->prepare("SELECT id, username, password, role FROM admins WHERE username = ?");
        $stmt->execute([$username]);
        $admin = $stmt->fetch(PDO::FETCH_ASSOC);

        if (!$admin) {
            $error = "Invalid username or password.";
        } elseif (!password_verify($password, $admin['password'])) {
            $error = "Invalid username or password.";
        } elseif ($admin['role'] != $submittedRole) {
            $error = "Role mismatch for this user.";
        } else {
            // Login successful: store session data
            $_SESSION['admin_id'] = $admin['id'];
            $_SESSION['admin_username'] = $admin['username'];
            $_SESSION['admin_role'] = $admin['role'];
            $_SESSION['admin_logged_in'] = true;

            header('Location: admin_dashboard.php');
            exit;
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>Admin Login</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <style>
    body { 
      background: linear-gradient(to right, #74ebd5, #ACB6E5); 
      min-height: 100vh; 
      display: flex; 
      align-items: center; 
      justify-content: center;
      margin: 0;
    }
    .login-container {
      width: 100%;
      max-width: 400px;
      padding: 30px;
      background-color: #ffffff;
      border-radius: 12px;
      box-shadow: 0 6px 15px rgba(0, 0, 0, 0.15);
    }
    .form-control, .form-select { border-radius: 8px; }
    .btn-primary {
      background-color: #3b6363;
      border: none;
      border-radius: 8px;
    }
    .btn-primary:hover { background-color: #2d4f4f; }
    .footer { margin-top: 20px; text-align: center; color: #555; font-size: 0.9rem; }
  </style>
</head>
<body>
<div class="login-container">
  <h3 class="text-center mb-4">Admin Login</h3>

  <?php if ($error): ?>
    <div class="alert alert-danger text-center p-2">
      <?= htmlspecialchars($error) ?>
    </div>
  <?php endif; ?>

  <form method="POST" action="" autocomplete="off">
    <div class="mb-3">
      <label for="username" class="form-label">Username</label>
      <input type="text" id="username" name="username" class="form-control" required autofocus value="<?= htmlspecialchars($_POST['username'] ?? '') ?>">
    </div>

    <div class="mb-3">
      <label for="password" class="form-label">Password</label>
      <input type="password" id="password" name="password" class="form-control" required>
    </div>

    <div class="mb-3">
      <label for="role" class="form-label">Select Role</label>
      <select id="role" name="role" class="form-select" required>
        <option value="" disabled <?= empty($_POST['role']) ? 'selected' : '' ?>>-- Select Role --</option>
        <option value="1" <?= (isset($_POST['role']) && $_POST['role'] == '1') ? 'selected' : '' ?>>Super Admin</option>
        <option value="2" <?= (isset($_POST['role']) && $_POST['role'] == '2') ? 'selected' : '' ?>>Loan Approver</option>
        <option value="3" <?= (isset($_POST['role']) && $_POST['role'] == '3') ? 'selected' : '' ?>>Loan Viewer</option>
        <option value="4" <?= (isset($_POST['role']) && $_POST['role'] == '4') ? 'selected' : '' ?>>Loan Consultant</option>
      </select>
    </div>

    <button type="submit" class="btn btn-primary w-100">Login</button>
  </form>

  <div class="footer mt-3">
    👉 Don't have an account? <a href="admin_register.php">Register here</a>
  </div>
</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
