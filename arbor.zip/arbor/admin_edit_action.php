<?php
session_start();

if (!isset($_SESSION['admin_id']) || $_SESSION['admin_role'] != 1) {
    header('Location: admin_login.php');
    exit;
}

include __DIR__ . '/db_connection.php';

function redirectWithMessage($message, $location = 'admin_management.php') {
    $_SESSION['flash'] = $message;
    header("Location: $location");
    exit;
}

$admin_id = intval($_POST['admin_id'] ?? 0);
$username = trim($_POST['username'] ?? '');
$email = trim($_POST['email'] ?? '');
$password = $_POST['password'] ?? '';
$role = intval($_POST['role'] ?? 0);

if (!$admin_id || !$username || !$email || !$role) {
    redirectWithMessage('Please fill all required fields.', "admin_edit.php?id=$admin_id");
}

if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    redirectWithMessage('Invalid email format.', "admin_edit.php?id=$admin_id");
}

// Check if username or email exists for other admins
$stmt = $pdo->prepare("SELECT id FROM admins WHERE (username = ? OR email = ?) AND id != ?");
$stmt->execute([$username, $email, $admin_id]);
if ($stmt->fetch()) {
    redirectWithMessage('Username or email already exists.', "admin_edit.php?id=$admin_id");
}

if ($password && strlen($password) < 6) {
    redirectWithMessage('Password must be at least 6 characters.', "admin_edit.php?id=$admin_id");
}

if ($password) {
    $passwordHash = password_hash($password, PASSWORD_DEFAULT);
    $stmt = $pdo->prepare("UPDATE admins SET username = ?, email = ?, password_hash = ?, role = ? WHERE id = ?");
    $stmt->execute([$username, $email, $passwordHash, $role, $admin_id]);
} else {
    $stmt = $pdo->prepare("UPDATE admins SET username = ?, email = ?, role = ? WHERE id = ?");
    $stmt->execute([$username, $email, $role, $admin_id]);
}

redirectWithMessage('Admin user updated successfully.', 'admin_management.php');
