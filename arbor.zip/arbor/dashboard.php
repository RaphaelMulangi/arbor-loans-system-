<?php
include 'navigation.php';
include __DIR__ . '/db_connection.php';

// Fetch loan statistics
$totalLoans = $approvedLoans = $rejectedLoans = $pendingLoans = 0;
$recentLoans = [];

try {
    // Count total applications
    $stmt = $pdo->query("SELECT COUNT(*) FROM loan_details");
    $totalLoans = $stmt->fetchColumn();

    // Approved
    $stmt = $pdo->query("SELECT COUNT(*) FROM loan_details WHERE status = 'approved'");
    $approvedLoans = $stmt->fetchColumn();

    // Rejected
    $stmt = $pdo->query("SELECT COUNT(*) FROM loan_details WHERE status = 'rejected'");
    $rejectedLoans = $stmt->fetchColumn();

    // Pending
    $stmt = $pdo->query("SELECT COUNT(*) FROM loan_details WHERE status = 'pending'");
    $pendingLoans = $stmt->fetchColumn();

    // Fetch recent loans with personal details (show more)
    $stmt = $pdo->query("SELECT l.id, p.full_name, l.loan_amount, l.status 
                         FROM loan_details l
                         JOIN personaldetails p ON p.id = l.id
                         ORDER BY l.created_at DESC
                         LIMIT 50");
    $recentLoans = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    die("DB Error: " . $e->getMessage());
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>Admin Dashboard - Arbor Finance</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <style>
    body { background-color: #f4f4f4; }
    .dashboard-container {
      padding: 30px;
      background-color: white;
      border-radius: 8px;
      box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
      margin-top: 30px;
    }
    .card { margin-bottom: 30px; }
    .footer {
      background-color: #3b6363;
      color: white;
      padding: 20px 0;
      text-align: center;
    }
    .navbar { background-color: #3b6363; }
    .navbar-nav .nav-link { color: white; }
    .scroll-table {
      max-height: 400px;
      overflow-y: auto;
    }
    .table thead th {
      position: sticky;
      top: 0;
      background-color: #343a40;
      color: white;
    }
  </style>
</head>
<body>

<div class="container">
  <div class="dashboard-container">
    <h2 class="text-center mb-4">Admin Dashboard</h2>

    <!-- Dashboard Overview -->
    <div class="row">
      <div class="col-md-3">
        <div class="card p-3 text-white bg-primary">
          <div class="card-body">
            <h5 class="card-title">Total Applications</h5>
            <p class="card-text"><?= $totalLoans ?></p>
          </div>
        </div>
      </div>

      <div class="col-md-3">
        <div class="card p-3 text-white bg-success">
          <div class="card-body">
            <h5 class="card-title">Approved Loans</h5>
            <p class="card-text"><?= $approvedLoans ?></p>
          </div>
        </div>
      </div>

      <div class="col-md-3">
        <div class="card p-3 text-white bg-danger">
          <div class="card-body">
            <h5 class="card-title">Rejected Loans</h5>
            <p class="card-text"><?= $rejectedLoans ?></p>
          </div>
        </div>
      </div>

      <div class="col-md-3">
        <div class="card p-3 text-white bg-warning">
          <div class="card-body">
            <h5 class="card-title">Pending Applications</h5>
            <p class="card-text"><?= $pendingLoans ?></p>
          </div>
        </div>
      </div>
    </div>

    <!-- Loan Applications Table -->
    <div class="mt-5">
      <h3>Recent Loan Applications</h3>
      <div class="scroll-table">
        <table class="table table-striped">
          <thead class="table-dark">
            <tr>
              <th>#</th>
              <th>Full Name</th>
              <th>Loan Amount</th>
              <th>Status</th>
              <th>Action</th>
            </tr>
          </thead>
          <tbody>
            <?php foreach ($recentLoans as $i => $loan): ?>
            <tr>
              <td><?= $i + 1 ?></td>
              <td><?= htmlspecialchars($loan['full_name']) ?></td>
              <td>ZMW <?= number_format($loan['loan_amount'], 2) ?></td>
              <td>
                <?php
                  $status = strtolower($loan['status']);
                  $badge = match ($status) {
                      'approved' => 'success',
                      'rejected' => 'danger',
                      'pending' => 'warning',
                      default => 'secondary'
                  };
                ?>
                <span class="badge bg-<?= $badge ?>"><?= ucfirst($status) ?></span>
              </td>
              <td><a href="view_loan.php?id=<?= $loan['id'] ?>" class="btn btn-info btn-sm">View</a></td>
            </tr>
            <?php endforeach; ?>
          </tbody>
        </table>
      </div>
    </div>

    <!-- Loan Management Actions -->
    <div class="mt-5">
      <h3>Manage Loans</h3>
      <div class="d-flex justify-content-between">
        <a href="add_loan.php" class="btn btn-primary">Delete Loan</a>
        
        <a href="export_loans.php" class="btn btn-warning">Export Data</a>
      </div>
    </div>
  </div>
</div>

<!-- Footer Section -->
<div class="footer">
  <p>&copy; 2025 Arbor Finance. All Rights Reserved.</p>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

<?php include 'footer.php'; ?>

</body>
</html>
