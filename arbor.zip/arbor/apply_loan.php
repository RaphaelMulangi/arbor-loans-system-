<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Loan Application Form</title>
</head>
<body>
    <h1>Loan Application Form</h1>

    <form action="submit_loan.php" method="POST" enctype="multipart/form-data">
        <fieldset>
            <legend>Personal Details</legend>
            <label>Full Name:</label><br>
            <input type="text" name="fullName" required><br><br>

            <label>Email:</label><br>
            <input type="email" name="email" required><br><br>

            <label>Phone:</label><br>
            <input type="text" name="phone" required><br><br>

            <label>NRC:</label><br>
            <input type="text" name="nrc" required><br><br>

            <label>Address:</label><br>
            <input type="text" name="homeAddress" required><br><br>

            <label>Location:</label><br>
            <input type="text" name="location"><br><br>

            <label>Occupation:</label><br>
            <input type="text" name="occupation"><br><br>

            <label>Institution:</label><br>
            <input type="text" name="institution"><br><br>

            <label>Upload NRC Front:</label><br>
            <input type="file" name="nrc_front" accept="image/*" required><br><br>

            <label>Upload NRC Back:</label><br>
            <input type="file" name="nrc_back" accept="image/*" required><br><br>
        </fieldset>

        <br>

        <fieldset>
            <legend>Loan Details</legend>
            <label>Bank Name:</label><br>
            <input type="text" name="bankName" required><br><br>

            <label>Account Number:</label><br>
            <input type="text" name="accountNumber" required><br><br>

            <label>Loan Amount:</label><br>
            <input type="number" name="loanAmount" step="0.01" required><br><br>

            <label>Interest Rate (%):</label><br>
            <input type="number" name="interestRate" step="0.01" required><br><br>

            <label>Loan Term (months):</label><br>
            <input type="number" name="loanTerm" required><br><br>

            <label>Loan Type:</label><br>
            <input type="text" name="loanType" required><br><br>

            <label>Loan Date:</label><br>
            <input type="date" name="loanDate" required><br><br>

            <label>Upload Payslip(s):</label><br>
            <input type="file" name="payment_slip[]" multiple accept="application/pdf,image/*" required><br><br>
        </fieldset>

        <br>

        <fieldset>
            <legend>Next of Kin</legend>
            <label>Kin Name:</label><br>
            <input type="text" name="kinName" required><br><br>

            <label>Kin Phone:</label><br>
            <input type="text" name="kinPhone" required><br><br>

            <label>Kin Address:</label><br>
            <input type="text" name="kinAddress" required><br><br>

            <label>Kin Location:</label><br>
            <input type="text" name="kinLocation"><br><br>

            <label>Kin Occupation:</label><br>
            <input type="text" name="kinOccupation"><br><br>

            <label>Kin Institution:</label><br>
            <input type="text" name="kinInstitution"><br><br>

            <label>Kin NRC:</label><br>
            <input type="text" name="kinNrc"><br><br>
        </fieldset>

        <br>
        <button type="submit">Submit Application</button>
    </form>
</body>
</html>
