<?php
session_start();

if (!isset($_SESSION['admin_id']) || $_SESSION['admin_role'] != 1) {
    header('Location: admin_login.php');
    exit;
}

include __DIR__ . '/db_connection.php';

$roles = [
    1 => "Super Admin",
    2 => "Loan Approver",
    3 => "Viewer",
    4 => "Exporter"
];

$admin_id = intval($_GET['id'] ?? 0);
if (!$admin_id) {
    header('Location: admin_management.php');
    exit;
}

// Fetch admin info without is_active
$stmt = $pdo->prepare("SELECT id, username, email, role FROM admins WHERE id = ?");
$stmt->execute([$admin_id]);
$admin = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$admin) {
    header('Location: admin_management.php');
    exit;
}

$flashMessage = '';
if (isset($_SESSION['flash'])) {
    $flashMessage = $_SESSION['flash'];
    unset($_SESSION['flash']);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1" />
<title>Edit Admin - Arbor Finance</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet" />
<style>
    body { background-color: #f4f4f4; }
    .container { padding: 30px; background: #fff; border-radius: 8px; margin-top: 30px; box-shadow: 0 4px 10px rgba(0,0,0,0.1); max-width: 600px; }
    .navbar { background: #3b6363; width: 100%; padding: 1rem 2rem; }
    .navbar .nav-link, .navbar .navbar-brand { color: #fff; }
    .navbar-brand img { height: 40px; object-fit: contain; }
</style>
</head>
<body>

<nav class="navbar navbar-expand-lg">
  <a class="navbar-brand d-flex align-items-center ms-3" href="admin_dashboard.php">
    <img src="img/arbor_Logo.jpg" alt="Arbor Finance Logo" class="me-2">
    <span style="color: white; font-size: 1.25rem;">Arbor Finance</span>
  </a>
</nav>

<div class="container">
  <h2>Edit Admin User</h2>
  <?php if ($flashMessage): ?>
    <div class="alert alert-danger alert-dismissible fade show" role="alert">
      <?= htmlspecialchars($flashMessage) ?>
      <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
  <?php endif; ?>

  <form method="POST" action="admin_edit_action.php">
    <input type="hidden" name="admin_id" value="<?= $admin['id'] ?>" />
    <div class="mb-3">
      <label for="username" class="form-label">Username</label>
      <input required type="text" id="username" name="username" class="form-control" maxlength="50" value="<?= htmlspecialchars($admin['username']) ?>" />
    </div>
    <div class="mb-3">
      <label for="email" class="form-label">Email</label>
      <input required type="email" id="email" name="email" class="form-control" maxlength="100" value="<?= htmlspecialchars($admin['email']) ?>" />
    </div>
    <div class="mb-3">
      <label for="password" class="form-label">Password (leave blank to keep current)</label>
      <input type="password" id="password" name="password" class="form-control" minlength="6" />
    </div>
    <div class="mb-3">
      <label for="role" class="form-label">Role</label>
      <select id="role" name="role" class="form-select" required>
        <?php foreach ($roles as $roleId => $roleName): ?>
          <option value="<?= $roleId ?>" <?= ($admin['role'] == $roleId) ? 'selected' : '' ?>><?= htmlspecialchars($roleName) ?></option>
        <?php endforeach; ?>
      </select>
    </div>

    <!-- Removed the is_active checkbox -->

    <button type="submit" class="btn btn-primary">Save Changes</button>
    <a href="admin_management.php" class="btn btn-secondary ms-2">Cancel</a>
  </form>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
