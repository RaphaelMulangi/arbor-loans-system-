<?php include 'navigation.php'; ?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8"/>
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>Contact Us - Arbor Finance</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet"/>
  <style>
    html, body {
      height: 100%;
      margin: 0;
    }
    body {
      display: flex;
      flex-direction: column;
      background-color: #f8f9fa;
    }
    .content {
      flex: 1 0 auto;
    }
    footer {
      flex-shrink: 0;
      background-color: #3b6363;
      color: white;
      text-align: center;
      padding: 1rem 0;
    }
    .navbar, .navbar.navbar-expand-lg {
      background-color: #3b6363 !important; /* Pale green */
    }
    .form-section {
      padding: 60px 0;
    }
    .contact-info {
      background-color: #e9ecef;
      padding: 20px;
      border-radius: 10px;
      margin-top: 40px;
    }
  </style>
</head>
<body>

<!-- Page Content -->
<div class="content">

  <!-- Contact Section -->
  <section class="form-section">
    <div class="container">
      <h2 class="text-center mb-4">Get in Touch</h2>
      <div class="row justify-content-center">
        <div class="col-md-8">
          <div class="card p-4">
            <h5>Contact Form</h5>
            <form id="contactForm">
              <div class="mb-3">
                <label for="name" class="form-label">Full Name</label>
                <input type="text" class="form-control" id="name" placeholder="Your Name" required />
              </div>
              <div class="mb-3">
                <label for="email" class="form-label">Email Address</label>
                <input type="email" class="form-control" id="email" placeholder="your@example.com" required />
              </div>
              <div class="mb-3">
                <label for="subject" class="form-label">Subject</label>
                <input type="text" class="form-control" id="subject" placeholder="Subject" required />
              </div>
              <div class="mb-3">
                <label for="message" class="form-label">Message</label>
                <textarea class="form-control" id="message" rows="4" placeholder="Your message..." required></textarea>
              </div>
              <button type="submit" class="btn btn-primary">Send Message</button>
            </form>
            <div id="formMessage" class="alert alert-success mt-3" style="display:none;">
              ✅ Message sent successfully!
            </div>
          </div>

          <!-- Contact Info with Map -->
          <div style="width: 100%; background-color: #e9ecef; padding: 40px 0;">
            <div style="text-align: center; max-width: 100%;">
              <h5>Contact Information</h5>
              <p><strong>Email:</strong> support@arborfinance.org</p>
              <p><strong>Phone:</strong>0972496392</p>
              <p><strong>Address:</strong> Plot 842/163, sub y, ndeke zcbc, Kitwe, Zambia</p>
            </div>

            <div style="width: 100%; height: 500px; margin-top: 20px;">
           <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3889.9436812113486!2d28.2401018!3d-12.8469141!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x196ce92d314a13bf%3A0x4e5dc6e9cf40ba3b!2sKCI%20Shopping%20Complex!5e0!3m2!1sen!2szm!4v1749473307215!5m2!1sen!2szm" 
            width="600"
             height="450" 
             style="border:0;" 
            allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade">
          </iframe>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>

</div>

<!-- Footer -->
<?php include 'footer.php' ?>

<!-- Scripts -->
<script>
  document.getElementById('contactForm').addEventListener('submit', function(e) {
    e.preventDefault();
    document.getElementById('formMessage').style.display = 'block';
    this.reset();
  });
</script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
