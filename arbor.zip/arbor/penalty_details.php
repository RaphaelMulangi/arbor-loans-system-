<?php
include 'db_connection.php';

$loanId = (int)($_GET['id'] ?? 0);
if (!$loanId) {
    echo "<p>Invalid loan ID.</p>";
    exit;
}

$stmt = $pdo->prepare("SELECT * FROM loan_penalties WHERE loan_id = ?");
$stmt->execute([$loanId]);
$penalties = $stmt->fetchAll(PDO::FETCH_ASSOC);

if (!$penalties) {
    echo "<p>No penalty history found for this loan.</p>";
    exit;
}

echo "<ul class='list-group'>";
foreach ($penalties as $penalty) {
    echo "<li class='list-group-item'>";
    echo "<strong>Date:</strong> " . htmlspecialchars($penalty['change_date']) . " | ";
    echo "<strong>Old Due Date:</strong> " . htmlspecialchars($penalty['old_due_date']) . " | ";
    echo "<strong>New Due Date:</strong> " . htmlspecialchars($penalty['new_due_date']);
    echo "</li>";
}
echo "</ul>";
