<?php
include 'navigation.php';
include 'db_connection.php';
session_start();

if ($_SESSION['role'] !== 'super_admin') {
    die("Access denied.");
}

$stmt = $pdo->query("
    SELECT a.name, l.action_type, l.action_details, l.created_at 
    FROM admin_actions l
    JOIN admins a ON l.admin_id = a.id
    ORDER BY l.created_at DESC
");

$logs = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<div class="container mt-5">
  <div class="dashboard-container">
    <h3>Admin Activity Logs</h3>
    <div class="scroll-table">
      <table class="table table-bordered table-hover">
        <thead class="table-dark">
          <tr>
            <th>Admin Name</th>
            <th>Action</th>
            <th>Details</th>
            <th>Date/Time</th>
          </tr>
        </thead>
        <tbody>
          <?php foreach ($logs as $log): ?>
          <tr>
            <td><?= htmlspecialchars($log['name']) ?></td>
            <td><?= htmlspecialchars($log['action_type']) ?></td>
            <td><?= htmlspecialchars($log['action_details']) ?></td>
            <td><?= htmlspecialchars($log['created_at']) ?></td>
          </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  </div>
</div>
