<?php
require 'db_connection.php';

if (!isset($_GET['loan_id'])) {
    echo "Invalid request.";
    exit;
}

$loanId = (int)$_GET['loan_id'];

// Fetch loan info
$stmt = $pdo->prepare("SELECT * FROM loan_details WHERE id = ?");
$stmt->execute([$loanId]);
$loan = $stmt->fetch();

if (!$loan) {
    echo "Loan not found.";
    exit;
}

// Fetch borrower info
$stmt = $pdo->prepare("SELECT * FROM users WHERE id = ?");
$stmt->execute([$loan['user_id']]);
$user = $stmt->fetch();

// Fetch penalty history
$penalties = $pdo->prepare("SELECT * FROM penalty_history WHERE loan_id = ? ORDER BY created_at DESC");
$penalties->execute([$loanId]);
?>

<h5>Borrower Info</h5>
<ul>
    <li><strong>Name:</strong> <?= htmlspecialchars($user['full_name']) ?></li>
    <li><strong>Email:</strong> <?= htmlspecialchars($user['email']) ?></li>
</ul>

<h5>Loan Info</h5>
<ul>
    <li><strong>Loan Amount:</strong> <?= number_format($loan['loan_amount'], 2) ?></li>
    <li><strong>Status:</strong> <?= htmlspecialchars($loan['repayment_status']) ?></li>
    <li><strong>Total Penalties:</strong> <?= number_format($loan['penalty_amount'], 2) ?></li>
</ul>

<h5>Penalty History</h5>
<?php if ($penalties->rowCount() > 0): ?>
    <table class="table table-bordered">
        <thead>
            <tr>
                <th>#</th>
                <th>Penalty Amount</th>
                <th>Date</th>
            </tr>
        </thead>
        <tbody>
            <?php $i = 1; foreach ($penalties as $p): ?>
            <tr>
                <td><?= $i++ ?></td>
                <td><?= number_format($p['penalty_amount'], 2) ?></td>
                <td><?= date("F j, Y", strtotime($p['created_at'])) ?></td>
            </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
<?php else: ?>
    <p>No penalties recorded.</p>
<?php endif; ?>
