<?php
// DB connection
$host = 'localhost';
$db   = 'arbor';
$user = 'root';
$pass = '';
$dsn = "mysql:host=$host;dbname=$db;charset=utf8mb4";

try {
    $pdo = new PDO($dsn, $user, $pass, [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION
    ]);
} catch (PDOException $e) {
    die("Database connection failed: " . $e->getMessage());
}

// Collect form data
$username = trim($_POST['username'] ?? '');
$email = trim($_POST['email'] ?? '');
$password = $_POST['password'] ?? '';
$confirmPassword = $_POST['confirm_password'] ?? '';
$role = $_POST['role'] ?? '';

if ($username === '' || $email === '' || $password === '' || $confirmPassword === '' || $role === '') {
    header("Location: admin_register.php?message=" . urlencode("All fields are required."));
    exit;
}

if ($password !== $confirmPassword) {
    header("Location: admin_register.php?message=" . urlencode("Passwords do not match."));
    exit;
}

// Check if role already exists
$stmt = $pdo->prepare("SELECT id FROM admins WHERE role = ?");
$stmt->execute([$role]);
if ($stmt->fetch()) {
    header("Location: admin_register.php?message=" . urlencode("An admin is already registered with this role."));
    exit;
}

// Optional: Check if username or email is already taken
$stmt2 = $pdo->prepare("SELECT id FROM admins WHERE username = ? OR email = ?");
$stmt2->execute([$username, $email]);
if ($stmt2->fetch()) {
    header("Location: admin_register.php?message=" . urlencode("Username or email already exists."));
    exit;
}

// Insert new admin
$hashedPassword = password_hash($password, PASSWORD_BCRYPT);
$insert = $pdo->prepare("INSERT INTO admins (username, email, password, role, is_logged_in) VALUES (?, ?, ?, ?, 0)");
$insert->execute([$username, $email, $hashedPassword, $role]);

header("Location: admin_login.php?message=" . urlencode("Admin registered successfully. Please log in."));
exit;
