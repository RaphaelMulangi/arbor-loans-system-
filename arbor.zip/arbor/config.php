<?php
require 'config.php'; // your database connection

// Sanitize inputs
$fullName = $_POST['fullName'];
$email = $_POST['email'];
$phone = $_POST['phone'];
$nrc = $_POST['nrc'];
$homeAddress = $_POST['homeAddress'];
$location = $_POST['location'];
$occupation = $_POST['occupation'];
$institution = $_POST['institution'];
$bankName = $_POST['bankName'];
$accountNumber = $_POST['accountNumber'];

// Insert into personaldetails
mysqli_query($conn, "INSERT INTO personaldetails 
(fullName, email, phone, nrc, homeAddress, location, occupation, institution, bankName, accountNumber) 
VALUES ('$fullName', '$email', '$phone', '$nrc', '$homeAddress', '$location', '$occupation', '$institution', '$bankName', '$accountNumber')");
$personal_id = mysqli_insert_id($conn);

// Next of kin
$kinName = $_POST['kinName'];
$kinPhone = $_POST['kinPhone'];
$kinAddress = $_POST['kinAddress'];
$kinLocation = $_POST['kinLocation'];
$kinOccupation = $_POST['kinOccupation'];
$kinInstitution = $_POST['kinInstitution'];
$kinNrc = $_POST['kinNrc'];

mysqli_query($conn, "INSERT INTO next_of_kin 
(personal_id, kinName, kinPhone, kinAddress, kinLocation, kinOccupation, kinInstitution, kinNrc) 
VALUES ('$personal_id', '$kinName', '$kinPhone', '$kinAddress', '$kinLocation', '$kinOccupation', '$kinInstitution', '$kinNrc')");

// Loan details
$loanAmount = $_POST['loanAmount'];
$interestRate = $_POST['interestRate'];
$loanTerm = $_POST['loanTerm'];
$loanType = $_POST['loanType'];
$loanDate = $_POST['loanDate'];

// Handle file uploads
$paymentSlipNames = [];
foreach ($_FILES['paymentSlip']['tmp_name'] as $key => $tmp_name) {
  $file_name = time().'_'.basename($_FILES['paymentSlip']['name'][$key]);
  move_uploaded_file($tmp_name, "uploads/" . $file_name);
  $paymentSlipNames[] = $file_name;
}
$slips = implode(",", $paymentSlipNames);

// NRC Photo
$nrcPhotoName = time().'_'.basename($_FILES['nrcPhoto']['name']);
move_uploaded_file($_FILES['nrcPhoto']['tmp_name'], "uploads/" . $nrcPhotoName);

mysqli_query($conn, "INSERT INTO loan_details 
(personal_id, loanAmount, interestRate, loanTerm, loanType, loanDate, paymentSlip, nrcPhoto) 
VALUES ('$personal_id', '$loanAmount', '$interestRate', '$loanTerm', '$loanType', '$loanDate', '$slips', '$nrcPhotoName')");

header("Location: thankyou.php");
?>
