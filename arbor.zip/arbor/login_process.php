<?php
session_start();
require __DIR__ . '/db_connection.php';  // Loads $pdo

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username_email = trim($_POST['username_email']);
    $password = $_POST['password'];

    // Prepare statement with placeholders
    $stmt = $pdo->prepare("SELECT id, username, password FROM users WHERE username = :ue OR email = :ue");
    $stmt->execute(['ue' => $username_email]);

    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($user) {
        // Verify password hash
        if (password_verify($password, $user['password'])) {
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['username'] = $user['username'];
            header('Location: ApplyNow.php');
            exit;
        } else {
            echo "Incorrect password. <a href='login.php'>Try again</a>";
        }
    } else {
        echo "User not found. <a href='register.php'>Register here</a>";
    }
} else {
    echo "Invalid request method.";
}
