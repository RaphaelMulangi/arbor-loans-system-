<?php include 'navigation.php'; ?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>Arbor Finance - Loan Repayment</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet"/>
  <style>
    body {
      background-color: #f1f3f5;
      display: flex;
      flex-direction: column;
      height: 100vh;
    }
    .form-section {
      min-height: 70vh;
      padding: 50px 0;
    }
    .content {
      flex: 1;
    }
    .navbar {
      background-color: #3B6363 !important;
    }
    .navbar-nav .nav-link {
      padding: 0.5rem 1rem;
    }
    .card {
      box-shadow: 0 0 10px rgba(0,0,0,0.05);
    }
    .summary-box {
      background-color: #f8f9fa;
      padding: 15px;
      border-radius: 8px;
    }
    footer {
      background-color: #3b6363;
      color: white;
    }
  </style>
</head>
<body>

<div class="content">
  <section class="form-section">
    <div class="container">
      <h2 class="text-center mb-4">Loan Repayment</h2>
      <div class="row justify-content-center">
        <div class="col-md-8">
          <div class="card p-4">
            <form id="repaymentForm" action="process_payment.php" method="POST" enctype="multipart/form-data">
              <div class="mb-3">
                <label for="loanRegNumber" class="form-label">Enter Loan Registration Number</label>
                <input type="text" name="loan_reg_number" class="form-control" id="loanRegNumber" placeholder="e.g. LN-2025-001234" required>
              </div>

              <button type="button" class="btn btn-primary btn-lg mb-3" onclick="loadLoanDetails()">Search Loan</button>

              <div id="loanDetails" class="mb-4" style="display: none;">
                <h5 class="mb-3">Loan Summary</h5>
                <div class="summary-box">
                  <p><strong>Full Name:</strong> <span id="repayName">—</span></p>
                  <p><strong>Total Due:</strong> ZMW <span id="repayTotal">—</span></p>
                  <p><strong>Monthly Installment:</strong> ZMW <span id="repayMonthly">—</span></p>
                  <p><strong>Remaining Balance:</strong> ZMW <span id="repayBalance">—</span></p>
                </div>

                <div class="mt-4">
                  <label for="repayAmount" class="form-label">Amount Paying (ZMW)</label>
                  <input type="number" name="repay_amount" class="form-control" id="repayAmount" required oninput="updateRemainingBalance()">
                </div>

                <div class="mt-2">
                  <p><strong>New Remaining Balance:</strong> ZMW <span id="updatedBalance">—</span></p>
                </div>

                <div class="mt-3">
                  <label for="batchNumber" class="form-label">Batch Number</label>
                  <input type="text" name="batch_number" class="form-control" id="batchNumber" required>
                </div>

                <div class="mt-3">
                  <label for="receiptUpload" class="form-label">Upload Payment Proof</label>
                  <input type="file" name="receipt_upload" class="form-control" id="receiptUpload" accept=".jpg,.jpeg,.png,.pdf" required>
                </div>

                <input type="hidden" name="form_type" value="repayment">

                <button type="submit" class="btn btn-primary btn-lg mt-4">Submit Repayment</button>
              </div>
            </form>
          </div>
        </div>
      </div>
    </div>
  </section>
</div>

<script>
  let currentBalance = 0;

  function loadLoanDetails() {
    const input = document.getElementById('loanRegNumber').value.trim();
    if (!input) {
      alert("Please enter a loan registration number.");
      return;
    }

    fetch(`get_loan_summary.php?loan_number=${encodeURIComponent(input)}`)
      .then(response => response.json())
      .then(data => {
        if (data.error) {
          alert(data.error);
          return;
        }

        document.getElementById("repayName").textContent = data.fullName;
        document.getElementById("repayTotal").textContent = data.totalDue;
        document.getElementById("repayMonthly").textContent = data.monthly;
        document.getElementById("repayBalance").textContent = data.balance;
        document.getElementById("updatedBalance").textContent = data.balance;

        currentBalance = data.balance;
        document.getElementById("loanDetails").style.display = "block";
      })
      .catch(error => {
        console.error("Error fetching loan details:", error);
        alert("An error occurred while fetching the loan details.");
      });
  }

  function updateRemainingBalance() {
    const amount = parseFloat(document.getElementById("repayAmount").value);
    if (!isNaN(amount)) {
      const newBalance = Math.max(currentBalance - amount, 0);
      document.getElementById("updatedBalance").textContent = newBalance.toFixed(2);
    } else {
      document.getElementById("updatedBalance").textContent = currentBalance.toFixed(2);
    }
  }
</script>

<?php include 'footer.php'; ?>
</body>
</html>
