<?php
include 'db_connection.php';

// Handle delete request
if (isset($_GET['delete_id'])) {
    $id = (int)$_GET['delete_id'];
    $pdo->prepare("DELETE FROM next_of_kin WHERE loan_id IN (SELECT id FROM loan_details WHERE user_id=?)")->execute([$id]);
    $pdo->prepare("DELETE FROM loan_details WHERE user_id=?")->execute([$id]);
    $pdo->prepare("DELETE FROM personaldetails WHERE id=?")->execute([$id]);
    header("Location: borrowers.php");
    exit;
}

// Handle borrower add/edit
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['save_borrower'])) {
    $id = $_POST['id'] ?? null;
    $full_name = $_POST['full_name'];
    $email = $_POST['email'];
    $phone = $_POST['phone'];
    $address = $_POST['address'];
    $location = $_POST['location'];
    $loan_amount = $_POST['loan_amount'];
    $date_applied = $_POST['date_applied'] ?? null; // NEW: capture date applied

    if ($id) {
        // Update borrower info
        $pdo->prepare("UPDATE personaldetails SET full_name=?, email=?, phone=?, address=?, location=? WHERE id=?")
            ->execute([$full_name, $email, $phone, $address, $location, $id]);

        // Check if loan record exists for this borrower
        $stmt = $pdo->prepare("SELECT id FROM loan_details WHERE user_id = ?");
        $stmt->execute([$id]);
        $loan = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($loan) {
            // Update existing loan amount and date_applied
            $pdo->prepare("UPDATE loan_details SET loan_amount = ?, date_applied = ? WHERE user_id = ?")
                ->execute([$loan_amount, $date_applied, $id]);
        } else {
            // Insert new loan record for borrower, date_applied as provided or NOW()
            $dateAppliedToUse = $date_applied ?: date('Y-m-d');
            $pdo->prepare("INSERT INTO loan_details (user_id, loan_amount, date_applied) VALUES (?, ?, ?)")
                ->execute([$id, $loan_amount, $dateAppliedToUse]);
        }

    } else {
        // Insert new borrower
        $pdo->prepare("INSERT INTO personaldetails (full_name, email, phone, address, location) VALUES (?, ?, ?, ?, ?)")
            ->execute([$full_name, $email, $phone, $address, $location]);

        // Get last inserted borrower id
        $newUserId = $pdo->lastInsertId();

        // Insert loan record for new borrower with date_applied = provided or now()
        $dateAppliedToUse = $date_applied ?: date('Y-m-d');
        $pdo->prepare("INSERT INTO loan_details (user_id, loan_amount, date_applied) VALUES (?, ?, ?)")
            ->execute([$newUserId, $loan_amount, $dateAppliedToUse]);
    }

    header("Location: borrowers.php");
    exit;
}

// Handle loan amount update
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_amount'])) {
    $loan_id = $_POST['loan_id'];
    $new_amount = $_POST['loan_amount'];
    $pdo->prepare("UPDATE loan_details SET loan_amount=? WHERE id=?")->execute([$new_amount, $loan_id]);
    header("Location: borrowers.php");
    exit;
}

// Handle due date update
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_due_date'])) {
    $loan_id = $_POST['loan_id'];
    $new_due_date = $_POST['due_date'];
    $pdo->prepare("UPDATE loan_details SET due_date=? WHERE id=?")->execute([$new_due_date, $loan_id]);
    header("Location: borrowers.php");
    exit;
}

// Fetch borrower list with loan details including date_applied
$stmt = $pdo->query("
    SELECT p.id as user_id, p.full_name, p.email, p.phone, p.address, p.location, 
           l.id as loan_id, l.loan_amount, l.due_date, l.date_applied
    FROM personaldetails p
    LEFT JOIN loan_details l ON p.id = l.user_id
    ORDER BY p.full_name
");
$borrowers = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Borrowers - Arbor Finance</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            display: flex;
            flex-direction: column;
            min-height: 100vh;
        }
        main {
            flex: 1;
        }
        .table-danger {
            background-color: #f8d7da;
        }
    </style>
</head>
<body>
<main class="container mt-4">
    <h2>Borrowers List</h2>
    <div class="d-flex justify-content-between mb-3">
        <button class="btn btn-primary" onclick="openAddModal()">Add Borrower</button>
        <a href="generate_borrowers_pdf.php" class="btn btn-success">Download PDF</a>
    </div>

    <table class="table table-bordered table-striped">
        <thead>
            <tr>
                <th>Full Name</th><th>Email</th><th>Phone</th><th>Address</th><th>Location</th><th>Loan Amount</th><th>Date Applied</th><th>Actions</th>
            </tr>
        </thead>
        <tbody>
        <?php foreach ($borrowers as $b): 
            $due_date = (strtotime($b['due_date']) !== false) ? new DateTime($b['due_date']) : null;
            $today = new DateTime();
            $isOverdue = $due_date && $due_date < $today;
            $rowClass = $isOverdue ? 'table-danger' : '';

            $dateAppliedDisplay = $b['date_applied'] ? (new DateTime($b['date_applied']))->format('Y-m-d') : '-';
        ?>
            <tr class="<?= $rowClass ?>">
                <td><?= htmlspecialchars($b['full_name']) ?></td>
                <td><?= htmlspecialchars($b['email']) ?></td>
                <td><?= htmlspecialchars($b['phone']) ?></td>
                <td><?= htmlspecialchars($b['address']) ?></td>
                <td><?= htmlspecialchars($b['location']) ?></td>
                <td>
                    <?= htmlspecialchars($b['loan_amount']) ?>
                    <?php if ($b['loan_id']): ?>
                        <button class="btn btn-sm btn-outline-secondary" onclick='openAmountModal(<?= json_encode($b) ?>)'>Edit</button>
                        <button class="btn btn-sm btn-outline-info" onclick='openDueDateModal(<?= json_encode($b) ?>)'>Reschedule</button>
                    <?php endif; ?>
                </td>
                <td><?= htmlspecialchars($dateAppliedDisplay) ?></td>
                <td>
                    <button class="btn btn-sm btn-warning" onclick='openEditModal(<?= json_encode($b) ?>)'>Edit</button>
                    <a href="?delete_id=<?= $b['user_id'] ?>" class="btn btn-sm btn-danger" onclick="return confirm('Delete borrower?')">Delete</a>
                </td>
            </tr>
        <?php endforeach; ?>
        </tbody>
    </table>
</main>

<!-- Borrower Modal -->
<div class="modal fade" id="borrowerModal" tabindex="-1">
    <div class="modal-dialog">
        <form method="POST" class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Borrower</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <input type="hidden" name="id" id="borrowerId">
                <input type="hidden" name="save_borrower" value="1">
                <input class="form-control mb-2" name="full_name" id="full_name" placeholder="Full Name" required>
                <input class="form-control mb-2" name="email" id="email" placeholder="Email" required>
                <input class="form-control mb-2" name="phone" id="phone" placeholder="Phone" required>
                <input class="form-control mb-2" name="address" id="address" placeholder="Address" required>
                <input class="form-control mb-2" name="location" id="location" placeholder="Location" required>
                <input class="form-control mb-2" name="loan_amount" id="loan_amount" placeholder="Loan Amount" required type="number" min="0" step="any">
                <!-- Editable Date Applied -->
                <label for="date_applied">Date Applied</label>
                <input class="form-control mb-2" name="date_applied" id="date_applied" placeholder="Date Applied" type="date" required>
            </div>
            <div class="modal-footer">
                <button class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                <button class="btn btn-primary" type="submit">Save</button>
            </div>
        </form>
    </div>
</div>

<!-- Amount Modal -->
<div class="modal fade" id="amountModal" tabindex="-1">
    <div class="modal-dialog">
        <form method="POST" class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Edit Loan Amount</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <input type="hidden" name="loan_id" id="loan_id">
                <input type="hidden" name="update_amount" value="1">
                <label for="loan_amount">Loan Amount</label>
                <input class="form-control" name="loan_amount" id="loan_amount_edit" required type="number" min="0" step="any">
            </div>
            <div class="modal-footer">
                <button class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                <button class="btn btn-primary" type="submit">Update</button>
            </div>
        </form>
    </div>
</div>

<!-- Due Date Modal -->
<div class="modal fade" id="dueDateModal" tabindex="-1">
    <div class="modal-dialog">
        <form method="POST" class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Edit Due Date</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <input type="hidden" name="loan_id" id="due_loan_id">
                <input type="hidden" name="update_due_date" value="1">
                <label for="due_date">New Due Date</label>
                <input class="form-control" type="date" name="due_date" id="due_date" required>
            </div>
            <div class="modal-footer">
                <button class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                <button class="btn btn-primary" type="submit">Update</button>
            </div>
        </form>
    </div>
</div>

<div class="container my-4 text-center">
    <a href="admin_dashboard.php" class="btn btn-outline-secondary">← Back to Dashboard</a>
</div>

<?php include 'footer.php'; ?>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script>
const modal = new bootstrap.Modal(document.getElementById('borrowerModal'));
const amountModal = new bootstrap.Modal(document.getElementById('amountModal'));
const dueDateModal = new bootstrap.Modal(document.getElementById('dueDateModal'));

function openAddModal() {
    document.getElementById('borrowerId').value = '';
    document.getElementById('full_name').value = '';
    document.getElementById('email').value = '';
    document.getElementById('phone').value = '';
    document.getElementById('address').value = '';
    document.getElementById('location').value = '';
    document.getElementById('loan_amount').value = '';
    document.getElementById('date_applied').value = '';
    modal.show();
}

function openEditModal(data) {
    document.getElementById('borrowerId').value = data.user_id;
    document.getElementById('full_name').value = data.full_name;
    document.getElementById('email').value = data.email;
    document.getElementById('phone').value = data.phone;
    document.getElementById('address').value = data.address;
    document.getElementById('location').value = data.location;
    document.getElementById('loan_amount').value = data.loan_amount ?? '';
    document.getElementById('date_applied').value = data.date_applied ? data.date_applied.split(' ')[0] : '';
    modal.show();
}

function openAmountModal(data) {
    document.getElementById('loan_id').value = data.loan_id;
    document.getElementById('loan_amount_edit').value = data.loan_amount;
    amountModal.show();
}

function openDueDateModal(data) {
    document.getElementById('due_loan_id').value = data.loan_id;
    document.getElementById('due_date').value = data.due_date ? data.due_date.split(' ')[0] : '';
    dueDateModal.show();
}
</script>
</body>
</html>
