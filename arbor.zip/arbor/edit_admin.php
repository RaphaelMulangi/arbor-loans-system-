<?php
include __DIR__ . '/db_connection.php';
session_start();

if ($_SESSION['role'] !== 'super_admin') {
    header('Location: dashboard.php');
    exit();
}

$id = $_GET['id'];
$stmt = $conn->prepare("SELECT * FROM admins WHERE id = ?");
$stmt->bind_param("i", $id);
$stmt->execute();
$admin = $stmt->get_result()->fetch_assoc();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = $_POST['name'];
    $email = $_POST['email'];
    $role = $_POST['role'];
    $status = $_POST['status'];

    $stmt = $conn->prepare("UPDATE admins SET name=?, email=?, role=?, status=? WHERE id=?");
    $stmt->bind_param("ssssi", $name, $email, $role, $status, $id);

    if ($stmt->execute()) {
        logAdminAction($_SESSION['admin_id'], 'Edit Admin', "Updated admin ID $id");
        header('Location: user_admin.php?msg=Admin updated');
    } else {
        echo "Error: " . $stmt->error;
    }
}
?>

<!-- Edit form -->
<form method="POST">
    <h2>Edit Admin</h2>
    <input type="text" name="name" value="<?= $admin['name'] ?>" required>
    <input type="email" name="email" value="<?= $admin['email'] ?>" required>
    <select name="role">
        <option value="admin" <?= $admin['role'] == 'admin' ? 'selected' : '' ?>>Admin</option>
        <option value="super_admin" <?= $admin['role'] == 'super_admin' ? 'selected' : '' ?>>Super Admin</option>
    </select>
    <select name="status">
        <option value="active" <?= $admin['status'] == 'active' ? 'selected' : '' ?>>Active</option>
        <option value="inactive" <?= $admin['status'] == 'inactive' ? 'selected' : '' ?>>Inactive</option>
    </select>
    <button type="submit">Update</button>
</form>
