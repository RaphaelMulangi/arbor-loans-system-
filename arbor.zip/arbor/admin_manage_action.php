<?php
session_start();

// Only allow Super Admin (role 1) to access
if (!isset($_SESSION['admin_id']) || ($_SESSION['admin_role'] ?? 0) != 1) {
    header('Location: admin_login.php');
    exit;
}

include __DIR__ . '/db_connection.php';

$flashMessage = '';
if (isset($_SESSION['flash'])) {
    $flashMessage = $_SESSION['flash'];
    unset($_SESSION['flash']);
}

function log_action($pdo, $adminId, $action, $targetId) {
    $stmt = $pdo->prepare("INSERT INTO admin_logs (admin_id, action, target_admin_id) VALUES (?, ?, ?)");
    $stmt->execute([$adminId, $action, $targetId]);
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    $currentAdminId = $_SESSION['admin_id'];

    if ($action === 'add') {
        $username = trim($_POST['username'] ?? '');
        $email = trim($_POST['email'] ?? '');
        $password = $_POST['password'] ?? '';
        $role = intval($_POST['role'] ?? 0);

        // Validate inputs
        if ($username === '' || $email === '' || $password === '' || !$role) {
            $_SESSION['flash'] = "❌ All fields are required.";
        } else {
            $existing = $pdo->prepare("SELECT COUNT(*) FROM admins WHERE email = ?");
            $existing->execute([$email]);
            if ($existing->fetchColumn()) {
                $_SESSION['flash'] = "❌ Email already exists.";
            } else {
                $stmt = $pdo->prepare("INSERT INTO admins (username, email, password, role, is_active, is_deleted, created_at) VALUES (?, ?, ?, ?, 1, 0, NOW())");
                $stmt->execute([
                    $username,
                    $email,
                    password_hash($password, PASSWORD_DEFAULT),
                    $role
                ]);
                $_SESSION['flash'] = "✅ Admin added successfully.";
            }
        }
    } elseif ($action === 'edit') {
        $adminId = intval($_POST['admin_id'] ?? 0);
        $email = trim($_POST['email'] ?? '');
        $role = intval($_POST['role'] ?? 0);
        $password = $_POST['password'] ?? '';

        if (!$adminId || $email === '' || !$role) {
            $_SESSION['flash'] = "❌ Invalid input.";
        } else {
            $existing = $pdo->prepare("SELECT COUNT(*) FROM admins WHERE email = ? AND id != ?");
            $existing->execute([$email, $adminId]);
            if ($existing->fetchColumn()) {
                $_SESSION['flash'] = "❌ Email already in use.";
            } else {
                $fields = ['email' => $email, 'role' => $role];
                if (!empty($password)) {
                    $fields['password'] = password_hash($password, PASSWORD_DEFAULT);
                }
                $setPart = implode(", ", array_map(fn($k) => "$k = :$k", array_keys($fields)));
                $fields['admin_id'] = $adminId;
                $fields['updated_by'] = $currentAdminId;
                $fields['updated_at'] = date("Y-m-d H:i:s");

                $stmt = $pdo->prepare("UPDATE admins SET $setPart, updated_by = :updated_by, updated_at = :updated_at WHERE id = :admin_id");
                $stmt->execute($fields);

                log_action($pdo, $currentAdminId, "edit", $adminId);
                $_SESSION['flash'] = "✏️ Admin updated.";
            }
        }
    } elseif ($action === 'delete') {
        $adminId = intval($_POST['admin_id'] ?? 0);
        if ($adminId) {
            $stmt = $pdo->prepare("UPDATE admins SET is_deleted = 1, updated_by = ?, updated_at = NOW() WHERE id = ?");
            $stmt->execute([$currentAdminId, $adminId]);

            log_action($pdo, $currentAdminId, "delete", $adminId);
            $_SESSION['flash'] = "🗑️ Admin moved to recycle bin.";
        }
    } elseif ($action === 'restore') {
        $adminId = intval($_POST['admin_id'] ?? 0);
        if ($adminId) {
            $stmt = $pdo->prepare("UPDATE admins SET is_deleted = 0, updated_by = ?, updated_at = NOW() WHERE id = ?");
            $stmt->execute([$currentAdminId, $adminId]);

            log_action($pdo, $currentAdminId, "restore", $adminId);
            $_SESSION['flash'] = "♻️ Admin restored.";
        }
    }

    header('Location: ' . $_SERVER['PHP_SELF']);
    exit;
}

$roles = [1 => "Super Admin", 2 => "Loan Approver", 3 => "Viewer", 4 => "Exporter"];
$admins = $pdo->query("SELECT * FROM admins ORDER BY created_at DESC")->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <title>Admin User Management</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet" />
    <style>
        .footer {
            text-align: center;
            margin-top: 40px;
            padding: 10px 0;
            color: #666;
            font-size: 14px;
        }
    </style>
</head>
<body>
<div class="container mt-5">
    <h2>Admin User Management</h2>

    <?php if ($flashMessage): ?>
        <div class="alert alert-info"><?= htmlspecialchars($flashMessage) ?></div>
    <?php endif; ?>

    <form method="POST" class="mb-4">
        <input type="hidden" name="action" value="add" />
        <div class="row g-2">
            <div class="col-md-3">
                <input name="username" class="form-control" placeholder="Username" required />
            </div>
            <div class="col-md-3">
                <input name="email" type="email" class="form-control" placeholder="Email" required />
            </div>
            <div class="col-md-3">
                <input name="password" type="password" class="form-control" placeholder="Password" required />
            </div>
            <div class="col-md-2">
                <select name="role" class="form-select" required>
                    <?php foreach ($roles as $key => $label): ?>
                        <option value="<?= $key ?>"><?= htmlspecialchars($label) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="col-md-1 d-grid">
                <button type="submit" class="btn btn-primary">Add</button>
            </div>
        </div>
    </form>

    <table class="table table-bordered table-striped align-middle">
        <thead>
            <tr>
                <th>#</th>
                <th>Username</th>
                <th>Email</th>
                <th>Role</th>
                <th>Status</th>
                <th>Created</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
        <?php if (empty($admins)): ?>
            <tr><td colspan="7" class="text-center">No admins found.</td></tr>
        <?php else: ?>
            <?php foreach ($admins as $i => $admin): ?>
                <tr>
                    <td><?= $i + 1 ?></td>
                    <td><?= htmlspecialchars($admin['username']) ?></td>
                    <td><?= htmlspecialchars($admin['email']) ?></td>
                    <td><?= $roles[$admin['role']] ?? 'Unknown' ?></td>
                    <td>
                        <?php if (!empty($admin['is_active'])): ?>
                            <span class="badge bg-success">Active</span>
                        <?php else: ?>
                            <span class="badge bg-secondary">Inactive</span>
                        <?php endif; ?>
                        <?php if (!empty($admin['is_deleted'])): ?>
                            <span class="badge bg-danger ms-1">Deleted</span>
                        <?php endif; ?>
                    </td>
                    <td><?= date('Y-m-d', strtotime($admin['created_at'])) ?></td>
                    <td>
                        <?php if (empty($admin['is_deleted'])): ?>
                            <button type="button" class="btn btn-info btn-sm mb-1" data-bs-toggle="modal" data-bs-target="#editModal<?= $admin['id'] ?>">Edit</button>
                            <form method="POST" style="display:inline;" onsubmit="return confirm('Move to recycle bin?');">
                                <input type="hidden" name="action" value="delete" />
                                <input type="hidden" name="admin_id" value="<?= $admin['id'] ?>" />
                                <button type="submit" class="btn btn-warning btn-sm">Delete</button>
                            </form>
                        <?php else: ?>
                            <form method="POST" style="display:inline;" onsubmit="return confirm('Restore admin?');">
                                <input type="hidden" name="action" value="restore" />
                                <input type="hidden" name="admin_id" value="<?= $admin['id'] ?>" />
                                <button type="submit" class="btn btn-success btn-sm">Restore</button>
                            </form>
                        <?php endif; ?>
                    </td>
                </tr>

                <!-- Edit Modal -->
                <div class="modal fade" id="editModal<?= $admin['id'] ?>" tabindex="-1" aria-labelledby="editModalLabel<?= $admin['id'] ?>" aria-hidden="true">
                    <div class="modal-dialog">
                        <form method="POST" class="modal-content">
                            <input type="hidden" name="action" value="edit" />
                            <input type="hidden" name="admin_id" value="<?= $admin['id'] ?>" />
                            <div class="modal-header">
                                <h5 class="modal-title" id="editModalLabel<?= $admin['id'] ?>">Edit <?= htmlspecialchars($admin['username']) ?></h5>
                                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                            </div>
                            <div class="modal-body">
                                <label for="email<?= $admin['id'] ?>" class="form-label">Email</label>
                                <input id="email<?= $admin['id'] ?>" name="email" type="email" class="form-control mb-2" value="<?= htmlspecialchars($admin['email']) ?>" required />

                                <label for="role<?= $admin['id'] ?>" class="form-label">Role</label>
                                <select id="role<?= $admin['id'] ?>" name="role" class="form-select mb-2" required>
                                    <?php foreach ($roles as $key => $label): ?>
                                        <option value="<?= $key ?>" <?= $admin['role'] == $key ? 'selected' : '' ?>><?= htmlspecialchars($label) ?></option>
                                    <?php endforeach; ?>
                                </select>

                                <label for="password<?= $admin['id'] ?>" class="form-label">New Password (optional)</label>
                                <input id="password<?= $admin['id'] ?>" name="password" type="password" class="form-control" placeholder="Leave blank to keep current password" />
                            </div>
                            <div class="modal-footer">
                                <button type="submit" class="btn btn-primary">Update</button>
                                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                            </div>
                        </form>
                    </div>
                </div>
            <?php endforeach; ?>
        <?php endif; ?>
        </tbody>
    </table>

    <!-- Back to Dashboard Button -->
    <div class="text-center my-4">
        <a href="admin_dashboard.php" class="btn btn-secondary">← Back to Dashboard</a>
    </div>

</div> <!-- End container -->
    <?php include 'footer.php'; ?>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
