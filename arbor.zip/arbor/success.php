<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Loan Application Submitted</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <style>
    body {
      background-color: #e9ecef;
      display: flex;
      align-items: center;
      justify-content: center;
      height: 100vh;
      flex-direction: column;
      text-align: center;
    }
    .success-box {
      background-color: #ffffff;
      padding: 40px;
      border-radius: 15px;
      box-shadow: 0 4px 8px rgba(0,0,0,0.1);
    }
    .checkmark {
      font-size: 50px;
      color: green;
    }
  </style>
</head>
<body>
  <div class="success-box">
    <div class="checkmark">✔️</div>
    <h2 class="mt-3">Application Submitted Successfully</h2>
    <p>Thank you for applying for a loan with Arbor Finance. Our team will review your application and get back to you shortly.</p>
    <a href="index.php" class="btn btn-primary mt-3">Back to Home</a>
  </div>
</body>
</html>
