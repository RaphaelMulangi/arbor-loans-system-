<?php
session_start();

if (!isset($_SESSION['admin_id']) || $_SESSION['admin_role'] != 1) {
    // Only Super Admin (role 1) allowed here
    header('Location: admin_manage_action.php');
    exit;
}

$adminUsername = $_SESSION['admin_username'];

include __DIR__ . '/db_connection.php';

// Flash message handler
$flashMessage = '';
if (isset($_SESSION['flash'])) {
    $flashMessage = $_SESSION['flash'];
    unset($_SESSION['flash']);
}

// Fetch all non-deleted admins
$stmt = $pdo->query("SELECT id, username, email, role, is_active, created_at FROM admins WHERE deleted_at IS NULL ORDER BY created_at DESC");
$admins = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Roles list for dropdown
$roles = [
    1 => "Super Admin",
    2 => "Loan Approver",
    3 => "Viewer",
    4 => "Exporter"
];
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1" />
<title>Admin User Management - Arbor Finance</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet" />
<style>
    body { background-color: #f4f4f4; }
    .container { padding: 30px; background: #fff; border-radius: 8px; margin-top: 30px; box-shadow: 0 4px 10px rgba(0,0,0,0.1); }
    .navbar { background: #3b6363; width: 100%; padding: 1rem 2rem; }
    .navbar .nav-link, .navbar .navbar-brand { color: #fff; }
    .navbar-brand img { height: 40px; object-fit: contain; }
    .footer { background: #3b6363; color: #fff; padding: 20px 0; text-align: center; margin-top: 30px; }
    .btn-sm { margin-right: 5px; }
</style>
</head>
<body>

<nav class="navbar navbar-expand-lg">
  <a class="navbar-brand d-flex align-items-center ms-3" href="admin_dashboard.php">
    <img src="img/arbor_Logo.jpg" alt="Arbor Finance Logo" class="me-2">
    <span style="color: white; font-size: 1.25rem;">Arbor Finance</span>
  </a>
</nav>

<div class="container">

  <div class="d-flex justify-content-between align-items-center mb-4">
    <h2>Admin User Management</h2>
    <a href="admin_logout.php" class="btn btn-danger">Logout</a>
  </div>

  <?php if ($flashMessage): ?>
    <div class="alert alert-success alert-dismissible fade show" role="alert">
      <?= htmlspecialchars($flashMessage) ?>
      <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
  <?php endif; ?>

  <!-- Add New Admin Form -->
  <div class="card mb-4">
    <div class="card-header">Add New Admin</div>
    <div class="card-body">
      <form method="POST" action="admin_manage_action.php">
        <input type="hidden" name="action" value="add" />
        <div class="mb-3">
          <label for="username" class="form-label">Username</label>
          <input required type="text" class="form-control" id="username" name="username" maxlength="50" />
        </div>
        <div class="mb-3">
          <label for="email" class="form-label">Email</label>
          <input required type="email" class="form-control" id="email" name="email" maxlength="100" />
        </div>
        <div class="mb-3">
          <label for="password" class="form-label">Password</label>
          <input required type="password" class="form-control" id="password" name="password" minlength="6" />
        </div>
        <div class="mb-3">
          <label for="role" class="form-label">Role</label>
          <select id="role" name="role" class="form-select" required>
            <?php foreach ($roles as $roleId => $roleName): ?>
              <option value="<?= $roleId ?>"><?= htmlspecialchars($roleName) ?></option>
            <?php endforeach; ?>
          </select>
        </div>
        <button type="submit" class="btn btn-primary">Add Admin</button>
      </form>
    </div>
  </div>

  <!-- Admins Table -->
  <h3>Existing Admins</h3>
  <div class="table-responsive">
  <table class="table table-striped table-hover align-middle">
    <thead>
      <tr>
        <th>#</th>
        <th>Username</th>
        <th>Email</th>
        <th>Role</th>
        <th>Status</th>
        <th>Created At</th>
        <th>Actions</th>
      </tr>
    </thead>
    <tbody>
      <?php if (empty($admins)): ?>
        <tr><td colspan="7" class="text-center">No admins found.</td></tr>
      <?php else: ?>
        <?php foreach ($admins as $i => $admin): ?>
          <tr>
            <td><?= $i + 1 ?></td>
            <td><?= htmlspecialchars($admin['username']) ?></td>
            <td><?= htmlspecialchars($admin['email']) ?></td>
            <td><?= $roles[$admin['role']] ?? 'Unknown' ?></td>
            <td>
              <?php if ($admin['is_active']): ?>
                <span class="badge bg-success">Active</span>
              <?php else: ?>
                <span class="badge bg-secondary">Inactive</span>
              <?php endif; ?>
            </td>
            <td><?= date('Y-m-d', strtotime($admin['created_at'])) ?></td>
            <td>
              <a href="admin_edit.php?id=<?= $admin['id'] ?>" class="btn btn-info btn-sm mb-1">Edit</a>
              
              <?php if ($admin['id'] != $_SESSION['admin_id']): ?>
                <form action="admin_manage_action.php" method="POST" style="display:inline;" onsubmit="return confirm('Are you sure you want to delete this admin?');">
                  <input type="hidden" name="action" value="delete" />
                  <input type="hidden" name="admin_id" value="<?= $admin['id'] ?>" />
                  <button type="submit" class="btn btn-danger btn-sm mb-1">Delete</button>
                </form>

                <form action="admin_manage_action.php" method="POST" style="display:inline;" onsubmit="return confirm('Are you sure you want to <?= $admin['is_active'] ? 'deactivate' : 'activate' ?> this admin?');">
                  <input type="hidden" name="action" value="toggle_active" />
                  <input type="hidden" name="admin_id" value="<?= $admin['id'] ?>" />
                  <button type="submit" class="btn btn-warning btn-sm mb-1">
                    <?= $admin['is_active'] ? 'Deactivate' : 'Activate' ?>
                  </button>
                </form>
              <?php else: ?>
                <span class="text-muted small">Current user</span>
              <?php endif; ?>
            </td>
          </tr>
        <?php endforeach; ?>
      <?php endif; ?>
    </tbody>
  </table>
  </div>

  <!-- Back to Dashboard Button -->
  <div class="text-center my-4">
    <a href="admin_dashboard.php" class="btn btn-secondary">← Back to Dashboard</a>
  </div>

</div> <!-- End container -->

<div class="footer">
  &copy; 2025 Arbor Finance. All Rights Reserved.<br>
  Designed by Raphael Mulangi
</div>


<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
