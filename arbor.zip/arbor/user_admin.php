<?php

include __DIR__ . '/db_connection.php';
session_start();

// Only allow super admins
if ($_SESSION['role'] != 'super_admin') {
    header('Location: dashboard.php');
    exit();
}

// Fetch admins
$admins = $conn->query("SELECT * FROM admins");

// Fetch recent actions
$actions = $conn->query("
    SELECT a.id, ad.name, a.action_type, a.action_details, a.action_time 
    FROM admin_actions a
    JOIN admins ad ON a.admin_id = ad.id
    ORDER BY a.action_time DESC LIMIT 50
");
?>

<!DOCTYPE html>
<html>
<head>
    <title>Admin Management</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
<h2>Admin Users</h2>
<table>
    <thead>
        <tr>
            <th>Name</th><th>Email</th><th>Role</th><th>Status</th><th>Actions</th>
        </tr>
    </thead>
    <tbody>
    <?php while($admin = $admins->fetch_assoc()): ?>
        <tr>
            <td><?= htmlspecialchars($admin['name']) ?></td>
            <td><?= htmlspecialchars($admin['email']) ?></td>
            <td><?= $admin['role'] ?></td>
            <td><?= $admin['status'] ?></td>
            <td>
                <a href="edit_admin.php?id=<?= $admin['id'] ?>">Edit</a> | 
                <a href="delete_admin.php?id=<?= $admin['id'] ?>" onclick="return confirm('Are you sure?')">Delete</a>
            </td>
        </tr>
    <?php endwhile; ?>
    </tbody>
</table>

<h2>Recent Admin Actions</h2>
<table>
    <thead>
        <tr>
            <th>Admin</th><th>Action</th><th>Details</th><th>Time</th>
        </tr>
    </thead>
    <tbody>
    <?php while($action = $actions->fetch_assoc()): ?>
        <tr>
            <td><?= htmlspecialchars($action['name']) ?></td>
            <td><?= htmlspecialchars($action['action_type']) ?></td>
            <td><?= htmlspecialchars($action['action_details']) ?></td>
            <td><?= $action['action_time'] ?></td>
        </tr>
    <?php endwhile; ?>
    </tbody>
</table>
</body>
</html>
