<?php
session_start();
include __DIR__ . '/db_connection.php'; // Ensure this contains your $pdo connection

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';
    $submittedRole = $_POST['role'] ?? '';

    // Validate inputs
    if (empty($username) || empty($password) || empty($submittedRole)) {
        $_SESSION['login_error'] = "Please fill in all fields.";
        header('Location: admin_login.php');
        exit;
    }

    try {
        // Check if someone else with this role is already logged in
        $stmtCheckRole = $pdo->prepare("SELECT username FROM admins WHERE role = :role AND is_logged_in = 1 LIMIT 1");
        $stmtCheckRole->execute(['role' => $submittedRole]);
        $loggedInAdmin = $stmtCheckRole->fetch(PDO::FETCH_ASSOC);

        if ($loggedInAdmin) {
            $_SESSION['login_error'] = "Admin '{$loggedInAdmin['username']}' with this role is already logged in.";
            header('Location: admin_login.php');
            exit;
        }

        // Fetch the admin by username
        $stmt = $pdo->prepare("SELECT id, username, password, role FROM admins WHERE username = :username");
        $stmt->bindParam(':username', $username);
        $stmt->execute();
        $admin = $stmt->fetch(PDO::FETCH_ASSOC);

        // Verify password and role
        if ($admin && password_verify($password, $admin['password']) && $admin['role'] == $submittedRole) {
            // Mark this admin as logged in
            $stmtUpdate = $pdo->prepare("UPDATE admins SET is_logged_in = 1 WHERE id = :id");
            $stmtUpdate->execute(['id' => $admin['id']]);

            $_SESSION['admin_id'] = $admin['id'];
            $_SESSION['admin_username'] = $admin['username'];
            $_SESSION['admin_role'] = $admin['role'];
            $_SESSION['admin_logged_in'] = true;

            // Redirect to dashboard
            header('Location: admin_dashboard.php');
            exit;
        } else {
            $_SESSION['login_error'] = "Invalid credentials or role mismatch.";
            header('Location: admin_login.php');
            exit;
        }

    } catch (PDOException $e) {
        $_SESSION['login_error'] = "Database error: " . $e->getMessage();
        header('Location: admin_login.php');
        exit;
    }
} else {
    // If accessed directly without POST
    header('Location: admin_login.php');
    exit;
}
