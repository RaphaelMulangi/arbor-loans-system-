<?php
session_start();
require_once 'db_connection.php';

header('Content-Type: application/json');

// Only allow access if admin is logged in
if (!isset($_SESSION['admin_id'])) {
    http_response_code(403);
    echo json_encode(['error' => 'Unauthorized']);
    exit;
}

// Sanitize loan number from query
$loanNumber = $_GET['loan_number'] ?? null;
if (!$loanNumber) {
    echo json_encode(['error' => 'Loan number is required']);
    exit;
}

// Normalize input (trim and uppercase to match DB values if needed)
$loanNumber = trim($loanNumber);

// DEBUG: You can uncomment this to verify input during development
// error_log("Searching for loan number: " . $loanNumber);

// Use binary-safe comparison to avoid collation issues
$stmt = $pdo->prepare("
    SELECT l.*, p.full_name 
    FROM loan_details l 
    JOIN personaldetails p ON p.id = l.user_id 
    WHERE BINARY TRIM(l.loan_number) = BINARY ?
");
$stmt->execute([$loanNumber]);
$loan = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$loan) {
    echo json_encode(['error' => 'Loan not found']);
    exit;
}

// Calculate total repayments
$repaymentStmt = $pdo->prepare("SELECT SUM(amount_paid) AS total_paid FROM repayments WHERE loan_id = ?");
$repaymentStmt->execute([$loan['id']]);
$totalPaid = (float) $repaymentStmt->fetchColumn();
$balance = (float) $loan['amount'] - $totalPaid;

echo json_encode([
    'fullName' => $loan['full_name'],
    'totalDue' => number_format($loan['amount'], 2),
    'monthly' => number_format($loan['monthly_installment'] ?? 0, 2),
    'balance' => number_format($balance, 2)
]);
