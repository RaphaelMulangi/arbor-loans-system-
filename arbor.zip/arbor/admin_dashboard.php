<?php
include 'navigation.php'; 
session_start();

if (!isset($_SESSION['admin_id'])) {
    header('Location: admin_login.php');
    exit;
}

$adminUsername = $_SESSION['admin_username'];
$adminRole     = $_SESSION['admin_role'];

// === Local Database connection ===
$host = 'localhost';
$db   = 'arbor';
$user = 'root';
$pass = '';
$charset = 'utf8mb4';

$dsn = "mysql:host=$host;dbname=$db;charset=$charset";

$options = [
    PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
];

try {
    $pdo = new PDO($dsn, $user, $pass, $options);
} catch (\PDOException $e) {
    die("Database connection failed: " . $e->getMessage());
}

$roleNames = [
    0 => "System Admin",
    1 => "Super Admin",
    2 => "Loan Approver",
    3 => "Loan Viewer",
    4 => "Loan Consultant"
];

$roleName = $roleNames[$adminRole] ?? "Unknown Role";

$flashMessage = '';
if (isset($_SESSION['flash'])) {
    $flashMessage = $_SESSION['flash'];
    unset($_SESSION['flash']);
}

// Stats
$totalLoans     = $pdo->query("SELECT COUNT(*) FROM loan_details")->fetchColumn();
$approvedLoans  = $pdo->query("SELECT COUNT(*) FROM loan_details WHERE status = 'approved'")->fetchColumn();
$rejectedLoans  = $pdo->query("SELECT COUNT(*) FROM loan_details WHERE status = 'rejected'")->fetchColumn();
$pendingLoans   = $pdo->query("SELECT COUNT(*) FROM loan_details WHERE status = 'pending'")->fetchColumn();

// Search and Pagination
$filter     = $_GET['due_filter'] ?? '';
$searchTerm = $_GET['search'] ?? '';
$page       = max((int)($_GET['page'] ?? 1), 1);
$limit      = 10;
$offset     = ($page - 1) * $limit;

$params = [];
$where = "WHERE 1";

if (!empty($searchTerm)) {
    $where .= " AND (p.full_name LIKE :search OR l.id = :loan_id)";
    $params[':search'] = "%$searchTerm%";
    $params[':loan_id'] = (int)$searchTerm;
}

if (!empty($filter)) {
    $where .= " AND l.status = 'approved'";

    switch ($filter) {
        case 'today':
            $where .= " AND DATE(l.due_date) = CURDATE()";
            break;
        case 'tomorrow':
            $where .= " AND DATE(l.due_date) = CURDATE() + INTERVAL 1 DAY";
            break;
        case 'next7':
            $where .= " AND DATE(l.due_date) BETWEEN CURDATE() AND CURDATE() + INTERVAL 7 DAY";
            break;
        case 'next30':
            $where .= " AND DATE(l.due_date) BETWEEN CURDATE() AND CURDATE() + INTERVAL 30 DAY";
            break;
    }
}

// Count filtered loans
$countStmt = $pdo->prepare("SELECT COUNT(*) FROM loan_details AS l JOIN personaldetails AS p ON p.id = l.user_id $where");
$countStmt->execute($params);
$totalLoansFiltered = $countStmt->fetchColumn();

// Fetch filtered loans with pagination
$stmt = $pdo->prepare("SELECT l.id, p.full_name, l.loan_amount, l.interest_rate, l.status, l.date_applied, l.due_date, l.repayment_status 
    FROM loan_details AS l 
    JOIN personaldetails AS p ON p.id = l.user_id 
    $where 
    ORDER BY l.date_applied DESC 
    LIMIT :limit OFFSET :offset");

foreach ($params as $key => &$val) {
    $stmt->bindParam($key, $val);
}
$stmt->bindValue(':limit', (int)$limit, PDO::PARAM_INT);
$stmt->bindValue(':offset', (int)$offset, PDO::PARAM_INT);
$stmt->execute();
$recentLoans = $stmt->fetchAll();

$totalPages = ceil($totalLoansFiltered / $limit);
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>Admin Dashboard - Arbor Finance</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet" />
  <style>
    body { background-color: #f4f4f4; }
    .sidebar {
      height: 100vh;
      background-color: #3b6363;
      padding-top: 30px;
      color: #fff;
      display: flex;
      flex-direction: column;
      justify-content: space-between;
    }
    .sidebar .nav-links {
      flex-grow: 1;
    }
    .sidebar a {
      color: #fff;
      display: block;
      padding: 10px 20px;
      text-decoration: none;
    }
    .sidebar a:hover {
      background-color: #295454;
    }
    .dashboard-container {
      padding: 30px;
      background: #fff;
      border-radius: 8px;
      box-shadow: 0 4px 10px rgba(0,0,0,0.1);
      margin-top: 30px;
    }
    .footer {
      background: #3b6363;
      color: #fff;
      padding: 20px 0;
      text-align: center;
      margin-top: 30px;
    }
    .scroll-table {
      max-height: 400px;
      overflow-y: auto;
    }
    .table thead th {
      position: sticky;
      top: 0;
      background: #343a40;
      color: #fff;
      z-index: 1;
    }
  </style>
</head>
<body>

<div class="container-fluid">
  <div class="row">
    <!-- Sidebar -->
    <div class="col-md-2 sidebar">
      <div>
        <div class="text-center mb-4">
          <img src="img/arbor_Logo.png" alt="Logo" style="width: 60px;">
          <h5 class="mt-2">Arbor Finance</h5>
        </div>
        <div class="nav-links">
          <?php if (in_array($adminRole, [0, 1])): ?>
            <a href="admin_management.php">Manage Admins</a>
            <a href="borrowers.php">Manage Users</a>
            <a href="reports.php">Reports</a>
          <?php elseif (in_array($adminRole, [2, 3])): ?>
            <a href="reports.php">Reports</a>
          <?php elseif ($adminRole == 4): ?>
            <a href="borrowers.php">Manage Users</a>
          <?php endif; ?>
        </div>
      </div>
      <div>
        <a href="admin_logout.php" class="d-block text-center py-3" style="background-color: #295454;">Logout</a>
      </div>
    </div>

    <!-- Main Dashboard -->
    <div class="col-md-10">
      <div class="dashboard-container">

        <h2 class="mb-4">Welcome, <?= htmlspecialchars($adminUsername) ?> (<?= $roleName ?>)</h2>

        <?php if (!empty($flashMessage)): ?>
          <div class="alert alert-success alert-dismissible fade show" role="alert">
            <?= htmlspecialchars($flashMessage) ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
          </div>
        <?php endif; ?>

        <!-- Stats -->
        <div class="row mb-4">
          <div class="col-md-3">
            <div class="card text-bg-primary text-center p-3">
              <h5>Total Loans</h5>
              <h2><?= $totalLoans ?></h2>
            </div>
          </div>
          <div class="col-md-3">
            <div class="card text-bg-success text-center p-3">
              <h5>Approved</h5>
              <h2><?= $approvedLoans ?></h2>
            </div>
          </div>
          <div class="col-md-3">
            <div class="card text-bg-danger text-center p-3">
              <h5>Rejected</h5>
              <h2><?= $rejectedLoans ?></h2>
            </div>
          </div>
          <div class="col-md-3">
            <div class="card text-bg-warning text-center p-3">
              <h5>Pending</h5>
              <h2><?= $pendingLoans ?></h2>
            </div>
          </div>
        </div>

        <!-- Filters -->
        <form method="GET" class="row g-3 mb-4">
          <div class="col-md-4">
            <select name="due_filter" class="form-select" onchange="this.form.submit()">
              <option value="">-- Filter by Due Date --</option>
              <option value="today" <?= $filter === 'today' ? 'selected' : '' ?>>Due Today</option>
              <option value="tomorrow" <?= $filter === 'tomorrow' ? 'selected' : '' ?>>Due Tomorrow</option>
              <option value="next7" <?= $filter === 'next7' ? 'selected' : '' ?>>Next 7 Days</option>
              <option value="next30" <?= $filter === 'next30' ? 'selected' : '' ?>>Next 30 Days</option>
            </select>
          </div>
          <div class="col-md-4">
            <input type="text" name="search" value="<?= htmlspecialchars($searchTerm) ?>" class="form-control" placeholder="Search by Name or Loan ID" />
          </div>
          <div class="col-md-2">
            <button class="btn btn-dark w-100">Search</button>
          </div>
        </form>

        <!-- Table -->
        <div class="scroll-table mb-4">
          <table class="table table-striped">
            <thead>
              <tr>
                <th>#</th>
                <th>Submitted</th>
                <th>Full Name</th>
                <th>Principal</th>
                <th>Repayment (30%)</th>
                <th>Status</th>
                <th>Due Date</th>
                <th>Repayment Status</th>
                <th>Actions</th>
              </tr>
            </thead>
            <tbody>
              <?php foreach ($recentLoans as $i => $loan): ?>
                <?php
                  $status = strtolower($loan['status']);
                  $badge = $status === 'approved' ? 'success' : ($status === 'rejected' ? 'danger' : 'warning');
                  $interestRate = $loan['interest_rate'] ?? 30;
                  $repaymentAmount = $loan['loan_amount'] + ($loan['loan_amount'] * $interestRate / 100);

                  // Repayment status badge logic: show 'N/A' for rejected loans
                  if ($status === 'rejected') {
                      $repaymentStatusText = 'N/A';
                      $repStatusBadge = 'secondary';
                  } else {
                      $repaymentStatusText = ucfirst($loan['repayment_status'] ?? 'N/A');
                      $repStatusBadge = match ($loan['repayment_status']) {
                          'paid' => 'success',
                          'missed' => 'danger',
                          'current' => 'secondary',
                          default => 'secondary'
                      };
                  }

                  // Due Date display logic
                  if ($status === 'approved') {
                      if (!empty($loan['due_date']) && strtotime($loan['due_date']) !== false) {
                          $dueDate = new DateTime($loan['due_date']);
                      } else {
                          $dueDate = (new DateTime($loan['date_applied']))->modify('+30 days');
                      }
                      $today = new DateTime();
                      $dueLabel = $dueDate < $today ? 'Overdue' : 'Due ' . $dueDate->format('d M Y');
                      $dueBadge = $dueDate < $today ? 'danger' : 'info';
                  } else {
                      $dueLabel = 'N/A';
                      $dueBadge = 'secondary';
                  }
                ?>
                <tr>
                  <td><?= $offset + $i + 1 ?></td>
                  <td><?= !empty($loan['date_applied']) ? date('Y-m-d', strtotime($loan['date_applied'])) : 'N/A' ?></td>
                  <td><?= htmlspecialchars($loan['full_name']) ?></td>
                  <td>K<?= number_format($loan['loan_amount'], 2) ?></td>
                  <td>K<?= number_format($repaymentAmount, 2) ?></td>
                  <td><span class="badge bg-<?= $badge ?>"><?= ucfirst($status) ?></span></td>
                  <td><span class="badge bg-<?= $dueBadge ?>"><?= $dueLabel ?></span></td>
                  <td><span class="badge bg-<?= $repStatusBadge ?>"><?= $repaymentStatusText ?></span></td>
                  <td>
                    <a href="view_loan.php?id=<?= $loan['id'] ?>" class="btn btn-info btn-sm">View</a>
                    <a href="loan_details.php?id=<?= $loan['id'] ?>" class="btn btn-secondary btn-sm">Details</a>

                    <?php if (in_array($adminRole, [0, 1, 2]) && $status === 'pending'): ?>
                      <form action="approve_loan.php" method="POST" style="display:inline;">
                        <input type="hidden" name="loan_id" value="<?= $loan['id'] ?>">
                        <button type="submit" class="btn btn-success btn-sm">Approve</button>
                      </form>
                      <form action="reject_loan.php" method="POST" style="display:inline;">
                        <input type="hidden" name="loan_id" value="<?= $loan['id'] ?>">
                        <button type="submit" class="btn btn-danger btn-sm">Reject</button>
                      </form>
                    <?php endif; ?>

                    <?php if (in_array($adminRole, [0, 1, 2]) && $status === 'approved'): ?>
                      <form action="update_repayment_status.php" method="POST" class="d-inline">
                        <input type="hidden" name="loan_id" value="<?= $loan['id'] ?>">
                        <select name="repayment_status" class="form-select form-select-sm d-inline w-auto">
                          <option value="current" <?= $loan['repayment_status'] === 'current' ? 'selected' : '' ?>>Current</option>
                          <option value="paid" <?= $loan['repayment_status'] === 'paid' ? 'selected' : '' ?>>Paid</option>
                          <option value="missed" <?= $loan['repayment_status'] === 'missed' ? 'selected' : '' ?>>Missed</option>
                        </select>
                        <button type="submit" class="btn btn-primary btn-sm">Update</button>
                      </form>
                    <?php endif; ?>
                  </td>
                </tr>
              <?php endforeach; ?>
              <?php if (empty($recentLoans)): ?>
                <tr>
                  <td colspan="9" class="text-center">No loans found.</td>
                </tr>
              <?php endif; ?>
            </tbody>
          </table>
        </div>

        <!-- Pagination -->
        <nav>
          <ul class="pagination">
            <?php for ($p = 1; $p <= $totalPages; $p++): ?>
              <li class="page-item <?= $p == $page ? 'active' : '' ?>">
                <a class="page-link" href="?<?= http_build_query(array_merge($_GET, ['page' => $p])) ?>"><?= $p ?></a>
              </li>
            <?php endfor; ?>
          </ul>
        </nav>

        <!-- Export / Delete -->
        <div class="mt-3 d-flex gap-2">
          <?php if (in_array($adminRole, [0, 1])): ?>
            <a href="Delete_loan.php" class="btn btn-danger">Delete Loans</a>
          <?php endif; ?>
          <?php if (in_array($adminRole, [0, 1, 4])): ?>
            <a href="export_loans.php" class="btn btn-warning">Export Approved Loans</a>
          <?php endif; ?>
        </div>

      </div>
    </div>
  </div>
</div>

<!-- footer -->
<?php include 'footer.php'; ?>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
