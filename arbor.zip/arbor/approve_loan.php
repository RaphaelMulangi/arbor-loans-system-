<?php
session_start();
if (!isset($_SESSION['admin_id'])) {
    header("Location: admin_login.php");
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['loan_id'])) {
    include 'db_connection.php';

    $loanId     = $_POST['loan_id'];
    $adminId    = $_SESSION['admin_id'];

    try {
        $stmt = $pdo->prepare("UPDATE loan_details SET status = 'approved', updated_by = ?, updated_at = NOW() WHERE id = ?");
        $stmt->execute([$adminId, $loanId]);

        $_SESSION['flash'] = "Loan ID #$loanId has been approved successfully.";
    } catch (PDOException $e) {
        $_SESSION['flash'] = "Error approving loan: " . $e->getMessage();
    }

    header("Location: admin_dashboard.php");
    exit;
}
?>
