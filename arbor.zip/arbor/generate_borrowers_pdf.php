<?php
require 'vendor/autoload.php'; // Path to Dompdf autoload
use Dompdf\Dompdf;
use Dompdf\Options;

include __DIR__ . '/db_connection.php';

try {
    $stmt = $pdo->prepare("
        SELECT 
            p.full_name, p.email, p.phone, p.address, p.location,
            l.loan_amount, l.interest_rate, l.loan_term, l.type, l.date_applied,
            k.kin_name, k.kin_phone, k.kin_address, k.kin_location
        FROM loan_details l
        JOIN personaldetails p ON p.id = l.user_id
        LEFT JOIN next_of_kin k ON k.loan_id = l.id
        ORDER BY l.date_applied DESC
    ");
    $stmt->execute();
    $borrowers = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    die("Database error: " . $e->getMessage());
}

// Build HTML for PDF
$html = '<h2>Borrowers List - Arbor Finance</h2>';
$html .= '<table border="1" cellpadding="6" cellspacing="0" width="100%">';
$html .= '<thead>
    <tr style="background-color: #f2f2f2;">
        <th>Full Name</th><th>Email</th><th>Phone</th><th>Location</th>
        <th>Loan Amount</th><th>Type</th><th>Interest</th><th>Term</th><th>Date Applied</th>
        <th>Next of Kin</th>
    </tr>
</thead><tbody>';

foreach ($borrowers as $b) {
    $html .= '<tr>
        <td>' . htmlspecialchars($b['full_name']) . '</td>
        <td>' . htmlspecialchars($b['email']) . '</td>
        <td>' . htmlspecialchars($b['phone']) . '</td>
        <td>' . htmlspecialchars($b['location']) . '</td>
        <td>ZMW ' . number_format($b['loan_amount'], 2) . '</td>
        <td>' . ucfirst(htmlspecialchars($b['type'])) . '</td>
        <td>' . number_format($b['interest_rate'], 2) . '%</td>
        <td>' . htmlspecialchars($b['loan_term']) . ' mo</td>
        <td>' . htmlspecialchars($b['date_applied']) . '</td>
        <td>' . htmlspecialchars($b['kin_name']) . '<br>' .
              htmlspecialchars($b['kin_phone']) . '<br>' .
              htmlspecialchars($b['kin_location']) . '</td>
    </tr>';
}

$html .= '</tbody></table>';

// Setup Dompdf
$options = new Options();
$options->set('defaultFont', 'Helvetica');
$dompdf = new Dompdf($options);

$dompdf->loadHtml($html);
$dompdf->setPaper('A4', 'landscape');
$dompdf->render();
$dompdf->stream("borrowers_list.pdf", ["Attachment" => false]);
exit;
