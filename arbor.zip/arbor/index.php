<?php include 'navigation.php'; ?>
<?php include 'loader.php'; ?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>Arbor Finance - Home</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>

  <style>
    body {
      background-color: #e9ecef;
    }
    .hero {
      background: linear-gradient(to right, #3b6363, #1c4040);
      color: white;
      padding: 80px 0;
    }
    .section {
      padding: 60px 0;
    }
    .feature-icon {
      font-size: 40px;
      color: #3b6363;
    }
    .about-img {
      max-width: 100%;
      border-top-right-radius: 20px;
      border-bottom-right-radius: 20px;
      box-shadow: 0 4px 8px rgba(0,0,0,0.2);
    }
    .team-img {
      width: 250px;
      height: 250px;
      object-fit: cover;
      border-radius: 50%;
      box-shadow: 0 8px 16px rgba(0,0,0,0.3);
      transition: transform 0.3s ease;
      cursor: pointer;
    }
    .team-img:hover {
      transform: scale(1.05);
    }
    .modal-content {
      opacity: 0;
      transform: translateY(30px);
      transition: opacity 0.5s ease, transform 0.5s ease;
    }
    .modal.show .modal-content {
      opacity: 1;
      transform: translateY(0);
    }
    .col-md-6 {
      text-align: center;
    }
  </style>
</head>

<body>

<!-- Features Section -->
<section class="section text-center" id="features">
  <div class="container">
    <h2 class="mb-5" style="color: #F15E22;">Why Choose Us?</h2>
    <div class="row justify-content-center">
      <div class="col-md-4">
        <div class="p-4">
          <div class="feature-icon mb-3">💳</div>
          <h5>Convenient Loan Services</h5>
          <p>Flexible loan options with quick application and processing.</p>
        </div>
      </div>
      <div class="col-md-4">
        <div class="p-4">
          <div class="feature-icon mb-3">⚡</div>
          <h5>Fast Approvals</h5>
          <p>We process and approve your loan within 24 hours.</p>
        </div>
      </div>
      <div class="col-md-4">
        <div class="p-4">
          <div class="feature-icon mb-3">🔒</div>
          <h5>Secure Transactions</h5>
          <p>Your data is protected with top-grade security standards.</p>
        </div>
      </div>
    </div>
  </div>
</section>

<!-- About Us Section -->
<section class="section bg-white" id="about">
  <div class="container">
    <h2 class="text-center mb-5" style="color: #F15E22;">About Us</h2>
    <div class="row align-items-center">
      <div class="col-md-6" style="background: rgba(0,0,0,.6); border-top-left-radius: 20px; border-bottom-left-radius: 20px; padding: .65rem;">
        <h4 style="color: #F15E22;">What We Do</h4>
        <p style="color: #ffffff">
          At Arbor Finance, we are committed to empowering individuals and businesses by providing flexible and accessible financial solutions. Whether you're looking for personal loans, business financing, or short-term cash advances, our services are tailored to meet your needs quickly and securely.
        </p>
        <h4 style="color: #F15E22;">Our Vision</h4>
        <p style="color: #ffffff">
          To become a leading financial service provider known for innovation, reliability, and customer satisfaction. We aim to simplify the borrowing process and make finance accessible to everyone, everywhere.
        </p>
        <h5 style="color: #F15E22;">Need Help?</h5>
        <p style="color: #ffffff">Reach us via our <i class='bx bxs-phone'></i> <a href="Contact.php">Contact Page</a> — we're here to assist you.</p>
      </div>
      <div class="col-md-6 text-center">
        <img src="img/ab.png" class="about-img">
      </div>
    </div>

    <!-- Our Team Section -->
<!-- Our Team Section -->
<div class="mt-5 pt-5 border-top">
  <h3 class="text-center mb-5">Meet Our Team</h3>
  <div class="row justify-content-center text-center">
  
    <!-- Mr Hezzy - Director (First) -->
    <div class="col-lg-3 col-md-4 col-sm-6 mb-5">
      <img src="img/hezzy.jpg" class="team-img mb-3" 
           data-name="Mr Hezzy" 
           data-title="Director" 
           data-bio="Mr. Hezzy is a core director at Arbor Finance, contributing strategic oversight and experience in loan structuring and client relations. His visionary leadership and deep financial expertise help shape the company’s success and client satisfaction." 
           data-img="img/hezzy.jpg" 
           data-bs-toggle="modal" data-bs-target="#teamModal">
      <h5 class="mb-0">Mr Hezzy</h5>
      <small class="text-muted">Director</small>
    </div>
  
    <!-- Existing Directors -->
    <div class="col-lg-3 col-md-4 col-sm-6 mb-5">
      <img src="img/james.jpg" class="team-img mb-3" data-name="Kulelwa James Chabala" data-title="Director" data-bio="As Director of Arbor Finance, James Chabala brings a wealth of leadership experience and a passion for empowering clients through accessible financial solutions. With a strong background in business development and strategic management, James is committed to driving the company's mission of providing flexible, secure, and client-focused financing options. His visionary leadership continues to shape Arbor Finance as a trusted partner for individuals and businesses alike." data-img="img/james.jpg" data-bs-toggle="modal" data-bs-target="#teamModal">
      <h5 class="mb-0">Kulelwa James Chabala</h5>
      <small class="text-muted">Director</small>
    </div>
    <div class="col-lg-3 col-md-4 col-sm-6 mb-5">
      <img src="img/yvette.jpg" class="team-img mb-3" data-name="Yvette Lwando Nkandu" data-title="Director-Finance" data-bio="Yvette Nkandu oversees all financial operations at Arbor Finance as the Director of Finance. With extensive experience in financial management and strategic planning, Yvette plays a critical role in ensuring the company’s financial health and operational excellence. She is committed to upholding the highest standards of financial integrity, ensuring that Arbor Finance remains a strong, reliable partner for every client." data-img="img/yvette.jpg" data-bs-toggle="modal" data-bs-target="#teamModal">
      <h5 class="mb-0">Yvette Lwando Nkandu</h5>
      <small class="text-muted">Director-Finance</small>
    </div>
    <div class="col-lg-3 col-md-4 col-sm-6 mb-5">
      <img src="img/nancy.jpg" class="team-img mb-3" data-name="Nancy Mwamba" data-title="Assistant Director-Finance" data-bio="As Assistant Director of Finance, Nancy Mwamba supports the financial leadership of Arbor Finance with a focus on precision, accountability, and innovation. Nancy works closely with the finance team to streamline processes, manage financial reporting, and promote sustainable growth. Her proactive approach and commitment to excellence help drive the success and resilience of Arbor Finance’s operations." data-img="img/nancy.jpg" data-bs-toggle="modal" data-bs-target="#teamModal">
      <h5 class="mb-0">Nancy Mwamba</h5>
      <small class="text-muted">Assistant Director-Finance</small>
    </div>
    <div class="col-lg-3 col-md-4 col-sm-6 mb-5">
      <img src="img/moses.jpg" class="team-img mb-3" data-name="Moses Chilambe Chabala" data-title="Loan Consultant" data-bio="Moses Chabala serves as a Loan Consultant at Arbor Finance, where he specializes in helping clients navigate their financial journeys. With a deep understanding of lending solutions and a client-first approach, Moses ensures that each borrower receives personalized support tailored to their unique needs. His dedication to transparency, efficiency, and client education makes him an invaluable asset to our team and a trusted advisor to our clients." data-img="img/moses.jpg" data-bs-toggle="modal" data-bs-target="#teamModal">
      <h5 class="mb-0">Moses Chilambe Chabala</h5>
      <small class="text-muted">Loan Consultant</small>
    </div>
  </div>
</div>

</section>

<!-- Team Modal -->
<div class="modal fade" id="teamModal" tabindex="-1" aria-labelledby="teamModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-lg modal-dialog-centered">
    <div class="modal-content text-center p-4">
      <div class="modal-header border-0">
        <button type="button" class="btn-close ms-auto" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body d-flex flex-column align-items-center">
        <img id="teamModalImg" src="" alt="Profile Image" class="rounded-circle mb-4"
             style="width: 180px; height: 180px; object-fit: cover; box-shadow: 0 6px 12px rgba(0,0,0,0.25);">
        <h4 id="teamModalLabel" class="mb-3"></h4>
        <p id="teamModalText" class="text-center px-4" style="max-width: 700px;"></p>
      </div>
    </div>
  </div>
</div>
<?php include 'footer.php'; ?>

<!-- Scripts -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script>
  const teamModal = document.getElementById('teamModal');
  teamModal.addEventListener('show.bs.modal', function (event) {
    const button = event.relatedTarget;
    const name = button.getAttribute('data-name');
    const title = button.getAttribute('data-title');
    const bio = button.getAttribute('data-bio');
    const img = button.getAttribute('data-img');

    document.getElementById('teamModalLabel').textContent = `${name} - ${title}`;
    document.getElementById('teamModalText').textContent = bio;
    document.getElementById('teamModalImg').src = img;
  });

  window.onload = function() {
    setTimeout(function() {
      document.getElementById('loaderWrapper').style.display = 'none';
      document.getElementById('content')?.classList.remove('hidden');
    }, 3000);
  };
</script>

</body>
</html>
