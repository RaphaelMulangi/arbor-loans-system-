-- phpMyAdmin SQL Dump
-- version 5.2.1
-- Host: 127.0.0.1
-- Generation Time: Aug 14, 2025
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";

-- --------------------------------------------------------
-- Table structure for table `admins`
DROP TABLE IF EXISTS `admins`;
CREATE TABLE `admins` (
  `id` int(11) NOT NULL,
  `username` varchar(100) NOT NULL,
  `is_active` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL,
  `role` tinyint(4) NOT NULL,
  `is_logged_in` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `deleted_at` datetime DEFAULT NULL,
  `is_deleted` tinyint(1) DEFAULT 0,
  `updated_by` int(11) DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Insert default Super Admin
INSERT INTO `admins` (`username`, `is_active`, `email`, `password`, `role`, `is_logged_in`) VALUES
('superadmin', 'yes', 'superadmin@example.com', '$2y$10$u1Xz6B0JZtqYqj7HqZMGbOSz8vTxGnK2vLX/lX/0vZlJ5EzI8vw2m', 1, 0);

-- --------------------------------------------------------
-- Table structure for table `admin_logs`
DROP TABLE IF EXISTS `admin_logs`;
CREATE TABLE `admin_logs` (
  `id` int(11) NOT NULL,
  `admin_id` int(11) DEFAULT NULL,
  `action` varchar(50) DEFAULT NULL,
  `target_admin_id` int(11) DEFAULT NULL,
  `timestamp` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `admin_logs` (`id`, `admin_id`, `action`, `target_admin_id`, `timestamp`) VALUES
(1, 1, 'delete', 1, '2025-05-29 12:24:49');

-- --------------------------------------------------------
-- Table structure for table `loan_details`
DROP TABLE IF EXISTS `loan_details`;
CREATE TABLE `loan_details` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `loan_amount` decimal(10,2) DEFAULT NULL,
  `interest_rate` decimal(5,2) DEFAULT NULL,
  `loan_term` int(11) DEFAULT NULL,
  `type` varchar(100) DEFAULT NULL,
  `date_applied` date DEFAULT NULL,
  `payment_slip` text DEFAULT NULL,
  `bank_name` varchar(100) DEFAULT NULL,
  `account_number` varchar(100) DEFAULT NULL,
  `nrc_front` text DEFAULT NULL,
  `nrc_back` text DEFAULT NULL,
  `loan_number` varchar(50) DEFAULT NULL,
  `status` varchar(20) DEFAULT 'pending',
  `updated_at` int(11) DEFAULT NULL,
  `updated_by` int(11) DEFAULT NULL,
  `due_date` varchar(20) DEFAULT 'pending',
  `repayment_status` varchar(50) DEFAULT 'pending',
  `penalty_amount` decimal(10,2) DEFAULT 0.00,
  `created_at` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------
-- Table structure for table `next_of_kin`
DROP TABLE IF EXISTS `next_of_kin`;
CREATE TABLE `next_of_kin` (
  `id` int(11) NOT NULL,
  `loan_id` int(11) NOT NULL,
  `kin_name` varchar(255) DEFAULT NULL,
  `kin_phone` varchar(20) DEFAULT NULL,
  `kin_address` text DEFAULT NULL,
  `kin_location` varchar(100) DEFAULT NULL,
  `kin_occupation` varchar(100) DEFAULT NULL,
  `kin_institution` varchar(100) DEFAULT NULL,
  `kin_nrc` varchar(50) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------
-- Table structure for table `penalty_history`
DROP TABLE IF EXISTS `penalty_history`;
CREATE TABLE `penalty_history` (
  `id` int(11) NOT NULL,
  `loan_id` int(11) NOT NULL,
  `penalty_reason` varchar(255) DEFAULT NULL,
  `penalty_amount` decimal(10,2) DEFAULT NULL,
  `penalty_date` date DEFAULT curdate(),
  `added_by` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------
-- Table structure for table `personaldetails`
DROP TABLE IF EXISTS `personaldetails`;
CREATE TABLE `personaldetails` (
  `id` int(11) NOT NULL,
  `full_name` varchar(255) NOT NULL,
  `email` varchar(255) DEFAULT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `nrc` varchar(50) DEFAULT NULL,
  `address` text DEFAULT NULL,
  `location` varchar(100) DEFAULT NULL,
  `occupation` varchar(100) DEFAULT NULL,
  `institution` varchar(100) DEFAULT NULL,
  `nrc_photo` varchar(255) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `nrc_number` varchar(50) DEFAULT NULL,
  `penalty_history` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------
-- Table structure for table `users`
DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `email` varchar(100) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `nrc` varchar(100) NOT NULL,
  `full_name` varchar(100) NOT NULL,
  `phone` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------
-- Indexes
ALTER TABLE `admins`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

ALTER TABLE `admin_logs`
  ADD PRIMARY KEY (`id`),
  ADD KEY `admin_id` (`admin_id`);

ALTER TABLE `loan_details`
  ADD PRIMARY KEY (`id`);

ALTER TABLE `next_of_kin`
  ADD PRIMARY KEY (`id`);

ALTER TABLE `penalty_history`
  ADD PRIMARY KEY (`id`),
  ADD KEY `loan_id` (`loan_id`);

ALTER TABLE `personaldetails`
  ADD PRIMARY KEY (`id`);

ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`);

-- --------------------------------------------------------
-- AUTO_INCREMENT
ALTER TABLE `admins`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

ALTER TABLE `admin_logs`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

ALTER TABLE `loan_details`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

ALTER TABLE `next_of_kin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

ALTER TABLE `penalty_history`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

ALTER TABLE `personaldetails`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

-- --------------------------------------------------------
-- Constraints
ALTER TABLE `admin_logs`
  ADD CONSTRAINT `admin_logs_ibfk_1` FOREIGN KEY (`admin_id`) REFERENCES `admins` (`id`);

ALTER TABLE `penalty_history`
  ADD CONSTRAINT `penalty_history_ibfk_1` FOREIGN KEY (`loan_id`) REFERENCES `loan_details` (`id`) ON DELETE CASCADE;

COMMIT;
