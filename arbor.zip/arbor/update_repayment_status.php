<?php
session_start();
require 'db_connection.php';

if (!isset($_POST['loan_id'], $_POST['repayment_status'])) {
    $_SESSION['flash'] = "Invalid request.";
    header("Location: admin_dashboard.php");
    exit;
}

$loanId = (int)$_POST['loan_id'];
$newStatus = $_POST['repayment_status'];

// Fetch current loan details
$stmt = $pdo->prepare("SELECT loan_amount, repayment_status, penalty_amount FROM loan_details WHERE id = ?");
$stmt->execute([$loanId]);
$loan = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$loan) {
    $_SESSION['flash'] = "Loan not found.";
    header("Location: admin_dashboard.php");
    exit;
}

// Define penalty rate (5%)
$penaltyRate = 0.05;

if ($newStatus === 'missed' && $loan['repayment_status'] !== 'missed') {
    // Apply penalty only when transitioning into 'missed' status
    $penalty = $loan['loan_amount'] * $penaltyRate;
    $updatedPenalty = $loan['penalty_amount'] + $penalty;

    // Update repayment status and penalty amount
    $update = $pdo->prepare("UPDATE loan_details SET repayment_status = ?, penalty_amount = ? WHERE id = ?");
    $update->execute([$newStatus, $updatedPenalty, $loanId]);

    // Log penalty in penalty_history table
    $log = $pdo->prepare("INSERT INTO penalty_history (loan_id, penalty_amount) VALUES (?, ?)");
    $log->execute([$loanId, $penalty]);
} else {
    // Just update the repayment status
    $update = $pdo->prepare("UPDATE loan_details SET repayment_status = ? WHERE id = ?");
    $update->execute([$newStatus, $loanId]);
}

$_SESSION['flash'] = "Repayment status updated successfully.";
header("Location: admin_dashboard.php");
exit;
?>
