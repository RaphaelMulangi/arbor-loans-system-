<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>Loading - Arbor Finance</title>

  <!-- 
    <style>
    /* Loader wrapper */
    .loader-wrapper {
      position: fixed;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      background-color: #fff8ee;
      display: flex;
      justify-content: center;
      align-items: center;
      flex-direction: column;
      z-index: 9999;
    }

    /* Circular Loader */
    .loader {
      border: 8px solid #f3f3f3;
      border-top: 8px solid red; /* Initial red color */
      border-radius: 50%;
      width: 80px;
      height: 80px;
      animation: spin 1s linear infinite, colorCycle 3s infinite linear;
    }
    /* Spinner rotation */
    @keyframes spin {
      0%   { transform: rotate(0deg); }
      100% { transform: rotate(360deg); }
    }

    /* Color change animation */
    @keyframes colorCycle {
      0%   { border-top-color: red; }    /* Red */
      33%  { border-top-color: blue; }   /* Blue */
      66%  { border-top-color: white; }  /* White */
      100% { border-top-color: red; }    /* Back to Red */
    }

  </style>

  -->

</head>
<body>

    <!--     <div class="loader-wrapper" id="loaderWrapper">
    <div class="loader"></div>
    <p class="mt-3">Loading Arbor Finance...</p>
  </div> -->


  <!-- Main Content (Hidden until loader is gone) -->
  <div id="content" class="hidden">
    <!-- Hero -->
    <header class="hero text-center" style="background: URL('img/hero.png') no-repeat; background-position: center;">
      <div class="container">
        <h1 class="display-4">Welcome to Arbor Finance</h1>
        <p class="lead">Smart, Fast & Secure Loan Solutions</p>
        <a href="#about" class="btn btn-light mt-3">Learn More</a>
      </div>
    </header>  
</body>
</html>
