<?php
// view_loan.php
include 'navigation.php';
include __DIR__ . '/db_connection.php';  // provides $pdo

$loan_id  = $_GET['id'] ?? null;
$errorMsg = '';
$loan     = null;

if (!$loan_id) {
    $errorMsg = "Loan ID is missing.";
} else {
    try {
        $sql = "
          SELECT 
            p.full_name, p.email, p.phone, p.address, p.location,
            l.loan_amount, l.interest_rate, l.loan_term, l.type, l.date_applied,
            l.nrc_front, l.nrc_back, l.payment_slip,
            k.kin_name, k.kin_phone, k.kin_address, k.kin_location, 
            k.kin_occupation, k.kin_institution, k.kin_nrc
          FROM loan_details l
          JOIN personaldetails p ON p.id = l.user_id
          LEFT JOIN next_of_kin k ON k.loan_id = l.id
          WHERE l.id = ?
        ";
        $stmt = $pdo->prepare($sql);
        $stmt->execute([$loan_id]);
        $loan = $stmt->fetch(PDO::FETCH_ASSOC);
        if (!$loan) $errorMsg = "Loan not found.";
    } catch (\PDOException $e) {
        $errorMsg = "Database error: " . $e->getMessage();
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>View Loan – Arbor Finance</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <style>
    .doc-img {
      max-height: 200px;
      object-fit: contain;
      border: 1px solid #ccc;
      padding: 4px;
      background: #f9f9f9;
      cursor: pointer;
    }
  </style>
</head>
<body>
<div class="container mt-5">
  <?php if ($errorMsg): ?>
    <div class="alert alert-danger"><?= htmlspecialchars($errorMsg) ?></div>
    <a href="admin_dashboard.php" class="btn btn-secondary">Back to Dashboard</a>
  <?php else: ?>
    <h3 class="mb-4">Loan Application Details</h3>
    <table class="table table-bordered mb-4">
      <tr><th>Full Name</th><td><?= htmlspecialchars($loan['full_name']) ?></td></tr>
      <tr><th>Email</th><td><?= htmlspecialchars($loan['email']) ?></td></tr>
      <tr><th>Phone</th><td><?= htmlspecialchars($loan['phone']) ?></td></tr>
      <tr><th>Address</th><td><?= htmlspecialchars($loan['address']) ?></td></tr>
      <tr><th>Location</th><td><?= htmlspecialchars($loan['location']) ?></td></tr>
      <tr><th>Loan Amount</th><td>ZMW <?= number_format($loan['loan_amount'],2) ?></td></tr>
      <tr><th>Interest Rate</th><td><?= number_format($loan['interest_rate'],2) ?>%</td></tr>
      <tr><th>Term (months)</th><td><?= htmlspecialchars($loan['loan_term']) ?></td></tr>
      <tr><th>Type</th><td><?= htmlspecialchars(ucfirst($loan['type'])) ?></td></tr>
      <tr><th>Date Applied</th><td><?= htmlspecialchars($loan['date_applied']) ?></td></tr>
      <tr><th>Due Date</th><td><?= date('Y-m-d', strtotime($loan['date_applied'].' +30 days')) ?></td></tr>
      <tr>
        <th>Next of Kin</th>
        <td>
          <strong>Name:</strong> <?= htmlspecialchars($loan['kin_name']) ?><br>
          <strong>Phone:</strong> <?= htmlspecialchars($loan['kin_phone']) ?><br>
          <strong>Address:</strong> <?= htmlspecialchars($loan['kin_address']) ?><br>
          <strong>Location:</strong> <?= htmlspecialchars($loan['kin_location']) ?><br>
          <strong>Occupation:</strong> <?= htmlspecialchars($loan['kin_occupation']) ?><br>
          <strong>Institution:</strong> <?= htmlspecialchars($loan['kin_institution']) ?><br>
          <strong>NRC:</strong> <?= htmlspecialchars($loan['kin_nrc']) ?>
        </td>
      </tr>
    </table>
<!-- Uploaded Documents -->
<h5 class="mt-4">Uploaded Documents</h5>
<div class="row">

  <!-- NRC Front -->
  <?php
  $nrcFront = $loan['nrc_front'];
  if (!empty($nrcFront)):
    $ext = strtolower(pathinfo($nrcFront, PATHINFO_EXTENSION));
  ?>
    <div class="col-md-4 mb-3 text-center">
      <label><strong>NRC Front</strong></label><br>
      <?php if (in_array($ext, ['jpg','jpeg','png','gif'])): ?>
        <img src="<?= htmlspecialchars($nrcFront) ?>"
             data-path="<?= htmlspecialchars($nrcFront) ?>"
             data-ext="<?= $ext ?>"
             class="img-fluid doc-img"
             alt="NRC Front">
      <?php elseif ($ext === 'pdf'): ?>
        <img src="https://via.placeholder.com/200x200?text=PDF"
             data-path="<?= htmlspecialchars($nrcFront) ?>"
             data-ext="<?= $ext ?>"
             class="img-fluid doc-img"
             alt="NRC Front PDF">
      <?php endif; ?>
    </div>
  <?php endif; ?>

  <!-- NRC Back -->
  <?php
  $nrcBack = $loan['nrc_back'];
  if (!empty($nrcBack)):
    $ext = strtolower(pathinfo($nrcBack, PATHINFO_EXTENSION));
  ?>
    <div class="col-md-4 mb-3 text-center">
      <label><strong>NRC Back</strong></label><br>
      <?php if (in_array($ext, ['jpg','jpeg','png','gif'])): ?>
        <img src="<?= htmlspecialchars($nrcBack) ?>"
             data-path="<?= htmlspecialchars($nrcBack) ?>"
             data-ext="<?= $ext ?>"
             class="img-fluid doc-img"
             alt="NRC Back">
      <?php elseif ($ext === 'pdf'): ?>
        <img src="https://via.placeholder.com/200x200?text=PDF"
             data-path="<?= htmlspecialchars($nrcBack) ?>"
             data-ext="<?= $ext ?>"
             class="img-fluid doc-img"
             alt="NRC Back PDF">
      <?php endif; ?>
    </div>
  <?php endif; ?>

  <!-- Payment Slips -->
  <?php
  $nrcBack = $loan['nrc_back'];
  if (!empty($nrcBack)):
    $ext = strtolower(pathinfo($nrcBack, PATHINFO_EXTENSION));
  ?>
    <div class="col-md-4 mb-3 text-center">
      <label><strong>Payment slip</strong></label><br>
      <?php if (in_array($ext, ['jpg','jpeg','png','gif'])): ?>
        <img src="<?= htmlspecialchars($nrcBack) ?>"
             data-path="<?= htmlspecialchars($nrcBack) ?>"
             data-ext="<?= $ext ?>"
             class="img-fluid doc-img"
             alt="Slip">
      <?php elseif ($ext === 'pdf'): ?>
        <img src="https://via.placeholder.com/200x200?text=PDF"
             data-path="<?= htmlspecialchars($nrcBack) ?>"
             data-ext="<?= $ext ?>"
             class="img-fluid doc-img"
             alt="Slip PDF">
      <?php endif; ?>
    </div>
  <?php endif; ?>

    <a href="admin_dashboard.php" class="btn btn-secondary mt-4">Back to Dashboard</a>
  <?php endif; ?>
</div>

<!-- Document Preview Modal -->
<div class="modal fade" id="docModal" tabindex="-1" aria-hidden="true">
  <div class="modal-dialog modal-xl modal-dialog-centered">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title">Document Preview</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
      </div>
      <div class="modal-body text-center" id="modalContent"></div>
    </div>
  </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script>
  document.querySelectorAll('.doc-img').forEach(el => {
    el.addEventListener('click', () => {
      const path = el.dataset.path;
      const ext  = el.dataset.ext.toLowerCase();
      const modal = new bootstrap.Modal(document.getElementById('docModal'));
      const container = document.getElementById('modalContent');

      container.innerHTML = ''; // Clear previous

      if (['jpg', 'jpeg', 'png', 'gif', 'webp'].includes(ext)) {
        container.innerHTML = `<img src="${path}" style="max-width:100%; max-height:80vh;" />`;
      } else if (ext === 'pdf') {
        container.innerHTML = `<iframe src="${path}" style="width:100%; height:80vh;" frameborder="0"></iframe>`;
      } else {
        container.innerHTML = `<p>Preview not available. <a href="${path}" class="btn btn-primary" target="_blank">Download File</a></p>`;
      }

      modal.show();
    });
  });
</script>
</body>
</html>
