<?php
include __DIR__ . '/db_connection.php';
session_start();

if ($_SESSION['role'] !== 'super_admin') {
    header('Location: dashboard.php');
    exit();
}

$id = $_GET['id'];

$stmt = $conn->prepare("UPDATE admins SET status='inactive' WHERE id=?");
$stmt->bind_param("i", $id);
$stmt->execute();

logAdminAction($_SESSION['admin_id'], 'Deactivate Admin', "Deactivated admin ID $id");

header('Location: user_admin.php?msg=Admin deactivated');
?>
