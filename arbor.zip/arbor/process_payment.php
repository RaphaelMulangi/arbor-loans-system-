<?php
include 'db_connect.php'; // Make sure you have this for DB connection

if ($_SERVER['REQUEST_METHOD'] === 'POST' && $_POST['form_type'] === 'repayment') {
    $loan_id = $_POST['loan_id'];
    $loan_reg_number = $_POST['loan_reg_number'];
    $repay_amount = floatval($_POST['repay_amount']);
    $batch_number = trim($_POST['batch_number']);

    // Validate file upload
    if (isset($_FILES['receipt_upload']) && $_FILES['receipt_upload']['error'] === UPLOAD_ERR_OK) {
        $uploadDir = 'uploads/receipts/';
        if (!is_dir($uploadDir)) {
            mkdir($uploadDir, 0755, true);
        }

        $fileTmp = $_FILES['receipt_upload']['tmp_name'];
        $fileName = basename($_FILES['receipt_upload']['name']);
        $targetPath = $uploadDir . time() . '_' . $fileName;

        if (move_uploaded_file($fileTmp, $targetPath)) {
            $receiptPath = $targetPath;
        } else {
            die("Failed to upload receipt.");
        }
    } else {
        die("No valid receipt uploaded.");
    }

    // Record the repayment
    $stmt = $conn->prepare("INSERT INTO repayments (loan_id, amount_paid, batch_number, receipt_path, payment_date)
                            VALUES (?, ?, ?, ?, NOW())");
    $stmt->bind_param("idss", $loan_id, $repay_amount, $batch_number, $receiptPath);

    if ($stmt->execute()) {
        // Update loan balance
        $updateStmt = $conn->prepare("UPDATE loan_details SET remaining_balance = remaining_balance - ? WHERE id = ?");
        $updateStmt->bind_param("di", $repay_amount, $loan_id);
        $updateStmt->execute();

        echo "<script>alert('Repayment recorded successfully.'); window.location.href='repayment_success.php';</script>";
    } else {
        echo "Error recording repayment.";
    }
} else {
    echo "Invalid request.";
}
?>
