<?php
session_start();
if (!isset($_SESSION['admin_id'])) {
    header('Location: admin_login.php');
    exit;
}

include __DIR__ . '/db_connection.php';

$loanId = $_GET['id'] ?? null;
if (!$loanId || !is_numeric($loanId)) {
    echo "Invalid loan ID.";
    exit;
}

// Fetch loan and user details
$stmt = $pdo->prepare("
    SELECT l.*, p.full_name, p.nrc_number, p.phone, p.address
    FROM loan_details AS l
    JOIN personaldetails AS p ON l.user_id = p.id
    WHERE l.id = ?
");
$stmt->execute([$loanId]);
$loan = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$loan) {
    echo "Loan not found.";
    exit;
}

// Fetch penalty history for this loan (without 'reason')
$penaltyStmt = $pdo->prepare("
    SELECT penalty_amount, penalty_date 
    FROM penalty_history 
    WHERE loan_id = ? 
    ORDER BY penalty_date DESC
");
$penaltyStmt->execute([$loanId]);
$penalties = $penaltyStmt->fetchAll(PDO::FETCH_ASSOC);

// Calculate due date fallback logic
if (!empty($loan['due_date']) && strtotime($loan['due_date']) !== false) {
    $dueDate = new DateTime($loan['due_date']);
} else {
    $dueDate = (new DateTime($loan['date_applied']))->modify('+30 days');
}
$dueDateFormatted = $dueDate->format('Y-m-d');
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Loan Details - Arbor Finance</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <style>
    body { background-color: #f9f9f9; }
    .container { margin-top: 40px; background: white; padding: 30px; border-radius: 8px; box-shadow: 0 4px 10px rgba(0,0,0,0.1); }
    .title { margin-bottom: 20px; }
    .back-btn { margin-bottom: 20px; }
  </style>
</head>
<body>

<div class="container">
  <a href="admin_dashboard.php" class="btn btn-secondary back-btn">← Back to Dashboard</a>
  <h2 class="title">Loan Details</h2>

  <div class="row">
    <div class="col-md-6">
      <h5>Borrower Info</h5>
      <ul class="list-group mb-4">
        <li class="list-group-item"><strong>Name:</strong> <?= htmlspecialchars($loan['full_name']) ?></li>
        <li class="list-group-item"><strong>NRC:</strong> <?= htmlspecialchars($loan['nrc_number']) ?></li>
        <li class="list-group-item"><strong>Phone:</strong> <?= htmlspecialchars($loan['phone']) ?></li>
        <li class="list-group-item"><strong>Address:</strong> <?= htmlspecialchars($loan['address']) ?></li>
      </ul>
    </div>

    <div class="col-md-6">
      <h5>Loan Info</h5>
      <ul class="list-group mb-4">
        <li class="list-group-item"><strong>Loan ID:</strong> <?= $loan['id'] ?></li>
        <li class="list-group-item"><strong>Amount:</strong> ZMW <?= number_format($loan['loan_amount'], 2) ?></li>
        <li class="list-group-item"><strong>Repayment (25%):</strong> ZMW <?= number_format($loan['loan_amount'] * 1.25, 2) ?></li>
        <li class="list-group-item"><strong>Status:</strong> <?= ucfirst($loan['status']) ?></li>
        <li class="list-group-item"><strong>Submitted:</strong> <?= date('Y-m-d', strtotime($loan['date_applied'])) ?></li>
        <li class="list-group-item"><strong>Due Date:</strong> <?= $dueDateFormatted ?></li>
        <li class="list-group-item"><strong>Repayment Status:</strong> <?= ucfirst($loan['repayment_status']) ?></li>
      </ul>
    </div>
  </div>

  <?php if (!empty($loan['documents'])): ?>
    <h5>Uploaded Documents</h5>
    <a href="uploads/<?= htmlspecialchars($loan['documents']) ?>" target="_blank" class="btn btn-outline-primary">View Document</a>
  <?php endif; ?>

  <!-- Penalty History -->
  <h5 class="mt-4">Penalty History</h5>
  <?php if (count($penalties) > 0): ?>
    <table class="table table-bordered">
      <thead>
        <tr>
          <th>Date</th>
          <th>Amount (ZMW)</th>
        </tr>
      </thead>
      <tbody>
        <?php foreach ($penalties as $penalty): ?>
          <tr>
            <td><?= htmlspecialchars(date('Y-m-d', strtotime($penalty['penalty_date']))) ?></td>
            <td><?= number_format($penalty['penalty_amount'], 2) ?></td>
          </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  <?php else: ?>
    <p>No penalties recorded for this loan.</p>
  <?php endif; ?>

</div>

</body>
</html>
